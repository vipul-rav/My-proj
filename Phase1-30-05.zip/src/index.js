
import 'babel-polyfill';
import React from 'react';
import { render } from 'react-dom';
import configureStore from './js/shared/store/configureStore';
import {Provider} from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import Routes from './routes';
//import './styles/styles.css'; //Webpack can import CSS files too!
 import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
// import '../node_modules/toastr/build/toastr.min.css';
import App from './js/components/App';
import ReactDOM from 'react-dom';

const store = configureStore();
const reactElement=document.getElementById('react');
 
export const Root = () => (
 <Provider store={store}>
    <BrowserRouter><App /></BrowserRouter>
  </Provider>
);
  
// ReactDOM.render(<div>asgdiuatsiu </div>, document.getElementById('react'));
if (!module.hot) {
  render(<Root />, reactElement);
}
