import React from 'react';
import PropTypes from 'prop-types';
//import dashboardPage from '../customer/dashboardPage';

class Form extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLogin: false,
      id: '',
      password: ''
    }
    this.redirectToDashboardPage = this.redirectToDashboardPage.bind(this);
    this.handleChangeId = this.handleChangeId.bind(this);
    this.handleChangePwd = this.handleChangePwd.bind(this);
  }

  redirectToDashboardPage() {
    this.props.redirectToDashboardPage(this.state.Id, this.state.password)
  }
  handleChangeId(e) {
    this.setState({ Id: e.target.value });
  }
  handleChangePwd(e) {
    this.setState({ password: e.target.value });
  }
  render() {
    return (
      <div className="container">
        <div className="row" >
          <div className="col-md-3"></div>
          <div className="col-md-6">
            <br />
            <label style={{ "marginLeft": "134px" }}>{this.props.errorMsg}</label>
            <br />
            <div className="row">
              <div className="col-md-4">
                <label style={{ "marginLeft": "70px" }}>User Id</label>
              </div>
              <div className="col-md-8" style={{ "marginBottom": "30px" }}>
                <input
                  type="Id"
                  name="Id"
                  defaultValue={this.state.id}
                  onChange={this.handleChangeId}
                  placeholder="User Id"
                  title="Enter your Use Id"
                />
              </div>
              <br />
              <div className="col-md-4">
                <label style={{ "marginLeft": "70px" }}>Password</label>
              </div>
              <div className="col-md-8">
                <input
                  type="password"
                  name="password"
                  defaultValue={this.state.password}
                  onChange={this.handleChangePwd}
                  placeholder="Password"
                  title="Type a strong <p></p>assword: aBC_123^"
                 
                />
              </div>
            </div>
            <br />
            <button type="submit" style={{ "marginLeft": "124px" }} disabled={this.state.id.length==0 && this.state.password.length==0} onClick={this.redirectToDashboardPage}>Login</button>
          </div>
          <div className="col-md-3"></div>
        </div>
      </div>
    );

  }
}

Form.propTypes = {
  redirectToDashboardPage: PropTypes.func.isRequired,
  errorMsg:PropTypes.string.isRequired
}

export default Form;

// pattern="^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,}$"