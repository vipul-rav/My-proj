import React, {PropTypes} from 'react';
import CustomerListRow from './CustomerListRow';
import CustomerSearch from './CustomerSearch';

const CustomerList = ({customers}) => {
  return (
    
    <table className="table">
      <thead>
      <tr>
        <th>&nbsp;</th>
        <th>Customer Id</th>
        <th>Name</th>
        <th>Address</th>
        <th>Post Code</th>
      </tr>
      </thead>
      <tbody>
          {customers.map(customer =>
        <CustomerListRow key={customer.custid} customer={customer}/>
      )}
      </tbody>
    </table>
    
  );
};

CustomerList.propTypes = {
  customers: PropTypes.array.isRequired
};

export default CustomerList;
