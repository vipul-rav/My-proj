import React, { PropTypes, Component } from 'react';
import CustomerList from './CustomerList';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as customerAction from '../../redux/actions/customerAction';
import FormGroup from 'react-bootstrap/lib/FormGroup';
import FormControl from 'react-bootstrap/lib/FormControl';
import Form from 'react-bootstrap/lib/Form';
import Row from 'react-bootstrap/lib/Row';
import Col from 'react-bootstrap/lib/Col';


class CustomerSearch extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      data: '',
      isSearch: false,
      last_name: ''
    }
    this.searchOnClick = this.searchOnClick.bind(this);
    this.handleSurnameChange = this.handleSurnameChange.bind(this);
    this.handleInitialChange = this.handleInitialChange.bind(this);
    this.handlePostcodeChange = this.handlePostcodeChange.bind(this);
  }

  searchOnClick() {

    this.setState({ isSearch: true })
    this.props.actions.loadCustomer(this.state.last_name, this.state.postcode);
  }
  onSave() {

  }
  handleSurnameChange(e) {
    this.setState({ last_name: e.target.value });
  }
  handleInitialChange(e) {
    this.setState({ initials: e.target.value });
  }
  handlePostcodeChange(e) {
    this.setState({ postcode: e.target.value })
  }
  render() {
    return (
      <div>

        <div className="container">
          <div className="row">
            <div className="col-md-2">

            </div>
            <div className="col-md-8">
              <Form>
                <Row>
                  <Col md={2}>
                    <div><label for="email">Bank:</label></div></Col>
                  <Col md={4}>
                    <FormGroup controlId="formControlsSelect">
                      <FormControl componentClass="select" placeholder="select">
                        <option value="select">Clydesdale Bank</option>
                        <option value="other">Yorkshire Bank</option>
                      </FormControl>
                    </FormGroup>

                  </Col>
                  <Col md={2}>
                    <button type="button" className="btn btn-info" onClick={this.searchOnClick}>Search</button>
                  </Col>
                </Row>
                <Row>
                  <Col md={2}><label for="email">Surname:</label></Col>
                  <Col md={4}><input type="text" value={this.state.last_name} placeholder="surname" onChange={this.handleSurnameChange} className="form-control" id="usr" /></Col>
                  <Col md={2}><button type="reset" className="btn btn-info">New Search</button></Col>
                </Row>
                <br />

                <Row>
                  <Col md={2}> <label for="email">1st Initial:</label> </Col>
                  <Col md={4}> <input type="text" placeholder="Initial" value={this.state.initials} onChange={this.handleInitialChange} className="form-control" id="usr" /></Col>
                </Row>
                <br />
                <Row>
                  <Col md={2}> <label for="email">Post Code</label> </Col>
                  <Col md={4}> <input type="text" placeholder="Post Code" value={this.state.postcode} onChange={this.handlePostcodeChange} className="form-control" id="usr" /></Col>
                </Row>
              </Form>
              <div> {"\n"}
                {this.props.customers.length > 0 && <CustomerList customers={this.props.customers} />}
              </div>
            </div>
            <div className="col-md-2">
            </div>
          </div>
        </div>
      </div>

    );
  }
}

CustomerSearch.propTypes = {
  customers: PropTypes.array.isRequired,
  actions: PropTypes.object.isRequired

};

function mapStateToProps(state, ownProps) {

  return {
    customers: state.customers
  };
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(customerAction, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(CustomerSearch);
