import React, {PropTypes} from 'react';
import { Link, NavLink } from 'react-router-dom';
import { DropdownButton, MenuItem } from 'react-bootstrap';
import LoadingDots from './LoadingDots';
import _ from 'lodash';



const Header = (menuItem) => { 
  /*const menus = _.map(menuItem, menues => _.map(menues, (menu, i) => {
    const subMenu = _.map(menu.submenu, (submenu, k) => {
      const link = _.toLower(_.join(_.split(submenu, ' '), '-'));
      return (<li key={k}><NavLink activeClassName="selected" to={link}>{submenu}</NavLink></li>);
    })
    return (
      <li className="nav-item" key={i}>
        <DropdownButton bsStyle="link" title={menu.title} id={`menuItem-${i}`} className="nav-link">
          {subMenu}
        </DropdownButton>
      </li>
    )
  })); //*/
  const menus = _.map(menuItem, menues => {
   return _.map(menues, (menu, i) => {
      return (<li className="nav-item" key={i}>
        <NavLink exact to={menu.title} className="nav-link" activeClassName="selected">{menu.title}</NavLink>
      </li>);
    });

   
  });
  return (
    <header>
      <nav className="navbar navbar-toggleable-md navbar-inverse fixed-top bg-inverse">
        <div className="collapse navbar-collapse">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item">
              <NavLink exact to="/" className="nav-link" activeClassName="selected">Home</NavLink></li>
              <NavLink to="/courses" activeClassName="active">Courses</NavLink>
          </ul>
        </div>
      </nav>
    </header>
  );
}

/*
const Header = ({loading}) => {
  return (
    <nav>
      <NavLink to="/" activeClassName="active">Home</NavLink>
      {" | "}
      <NavLink to="/courses" activeClassName="active">Courses</NavLink>
      {" | "}
      {loading && <LoadingDots interval={100} dots={20}/>}
    </nav>
  );
};*/

Header.propTypes = {
  loading: PropTypes.bool.isRequired
};

export default Header;
