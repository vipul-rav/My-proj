
import { makeAjaxCall } from '../../shared/helpers';
import { ApiBaseUrl, isStub, stubConfig, apiVersions } from '../../../config/serviceConfig';
const _getPersonList = '/banks/{bank-id}/accounts/default';

let customers = []

class CustomerApi {
  static getAllCustomers(last_name, postcode, dispatch, success, failure) {

    let url = ApiBaseUrl() + _getPersonList;
    if (isStub)
      url = ApiBaseUrl() + stubConfig.customerList;

    makeAjaxCall({
      apiVersion: apiVersions.customerListService,
      method: 'GET',
      url,
      addAuthToken: true
    }, (body, status) => {
      dispatch(success(body));
    }, (error, status) => {
      console.log('error..', error);
      dispatch(failure([]));
    });
  }
}

export default CustomerApi;

