
import { makeAjaxCall } from '../../shared/helpers';
import { ApiBaseUrl, isStub, stubConfig, apiVersions } from '../../../config/serviceConfig';
const _getLogin = '/banks/{bank-id}/accounts/default';
import _ from 'lodash';
const GenericMapperUtils = require('../../shared/utils/GenericMapperUtils');
//import JSEncrypt from '../../../static/jsencrypt.min.js';
//const JSEncrypt = require('../../../static/jsencrypt.min.js');

class loginApi {
  static loginDetail(id, password, dispatch, success, failure) {
   /* makeAjaxCall({
      apiVersion: '0.8.0',
      method: 'GET',
      url: "https://my-dev.cybservices.co.uk/bpiInt3/users/INTUSER38",
      addAuthToken: true
    },
      (body, status) => {
        console.log('body..', body);
        //dispatch(success(body));

      }, (error, status) => {
        console.log('error..', error);

      });


    makeAjaxCall({
      apiVersion: '0.8.0',
      method: 'POST',
      url: "https://my-dev.cybservices.co.uk/bpiInt3/banks/CB/auth/provider/oauth2/token/challenges",
      addAuthToken: true,
      body: JSON.stringify({ "user_identity": { "user_id": "INTUSER38" }, "scope": "30" })
    },
      (body, status) => {
        console.log('challange body..', body);
        let data = Object.assign({}, body);
        const pass = this.getSecretAnswer(data)
        data.userIdentity = "INTUSER38";
        data.challengeResponse = body;
        data.authData = {
          "partial-password": pass,
          "security-questions": [
            {
              "0": 'hysb/U3YlzbFAvPY6fb4Cpb8nK84gsKRieSI2NX0LlN+i+yhOU8/bSWgqeGEyS5vMzAwU9BLKnudOz1QANMn0uGMs4OSB3+JSpevZtN+CxXhih8Q/vWKjOWkCt21sSZYxOQhROPv7bI6GrGvvFCgIPtOF+6qLZfAbSkZw7SLv1QhsqTi3dNa1fG0SQCwbCmfT6SgBgHbqa8yocIWHQdM/bU6zWmRZuUgK12LAsPXlnmJgbaeVrdc1ki8sjme/IcCfTOIyQ6Ei7j1S3AH8H859wlbZ64ujmL8VBmn7mk16uaef8n+dkD+tJgFP3hNxoJ32ycgCG65RZ7N8GDmUu4X3A=='
              //this.encryptAnswer(data, "test123")
            }
          ]
        };
        console.log(data);
        this.callTokenAPI(data);

      }, (error, status) => {
        console.log('error..', error);

      });

*/

    //console.log("stub callng...");
    let url = ApiBaseUrl() + _getLogin;
    if (isStub)
      url = ApiBaseUrl() + stubConfig.login;

    makeAjaxCall({
      apiVersion: apiVersions.authServices,
      method: 'GET',
      url,
      addAuthToken: false,
      body: null

    }, (body, status) => {
      dispatch(success(body));
    }, (error, status) => {
      console.log('error..', error);
      dispatch(failure([]));
    });



  }

  static getSecretAnswer(body) {
    console.log(body.auth_schemes[0].challenges);
    const pass = ['P', 'a', 's', 's', 'w', 'o', 'r', 'd', '@', '1', '2', '3']
    const passEnc = ['Zx0Er3zhBjVqUF51HvpvnMRWa2bd1TWlSPLWvCMeOk7mkImjxjCd4EfYQtWYFv7GGZmIoUcj5eM3T5QxdC/mG4GlT5ZPMoZf+5uiuYEn12T246ZQG6wkqR3PghKTL9TeS3D+vMW/G9AZPwnjgOpC9I93NNrHgueFbWMpOO19NNs+Ii1IDDwK/uZ9pX+cqBX/AsP4TQag2TI6Sqw4zA7xMlQ0jdaBizgJ+ieiTGKCFuqU5AW/HIq8xD9aHT1lES9757/mR2d3z8UIZWQnO+Rbwxg5gzLwb1OFOgPUHxN+u0UvEEXzn2iVE5n8Wx6L2+h2n6rSYyM9bPbdypQZFfIHIA=='
      , 'nsxLuwRHCee4FsQDdmQk3zgUV5GcI0jWzlDF8LcOAoVYLHzEPs6ZpPv4tecKhSdgwYrMMxLolT3sX8SrawixrdpiEksJ3ktgE+bE1ERURwtTdx9MotXxx7HiYbNcL0bSqGQFu+cJJ+4eIRr50A96PoQ4XwFDluUtaR80L81EGCc+KjEPZubuEHv61uYLeL6lrnu1nIyr/oYZtJFx/uOgqlzdirmKdD8qlV+tNXc+03YxWoWonBEfHAukUVcQu7o2MfwbtbA0W+8I1MxMepraxbz0ijjwh8STSivgpzNxJrwmyrn+bL9CPz0gPl8OV/YaQkR/LGKho+4UAowUBLcWcA=='
      , 'FsGeB99G5FBZGziMyc1W28JEWFY2sGSvgluD7HcVIVQGlnfO2Ti9MOWm+KdJfbzPtR+XXg526z/RC3c9Fiqdsb9Od575lfoqyAnU+465TZLm0L40r7uVbCOD/K4BreYv2MkixZQeKpIXQ9FlFTqGAPLw9ERWbNdKMjOfO/PKUThzeDjwRsS3wHW+KVG7bKnHeK17dAdKfYCNtUDbJS8/Hu1H03mkXLsaIgdoJBCOGowxnJQ+F6mzPJr/8QB4a+bYnlOgZfBcxBEnNhXypcFKd6Thfpc0HJ0onXriiZPuEdXMU9u7Lb+OOGGJpVkgAODW5dlxlq7+ChGNZj2fBr9r4w=='
      , 'kvszhsJYPXh22NSnaFjNrLHSDQOJCcEVztxt2f01hOUqSqVO8NJWaWXTfJWDsZepN6I5fxu5ceZNULDTJdbMUe03ZCoTh4cX1r32hcKZKTzFaldwbZi4D1qRC2zwpkGsTmb+gGKS5KcMdIjuLplpHsLT5A9YY5c7TcPrHxR73FiblbauFDXxO8dq6hsqa9srWdBvM4Onwcqp9HR/kPVTi7RF+zsGtbgMiSXxEEOT/SyraAY25t+L8kjC5Yzoaj1SLw0PRQu0ifoRDLnsaJeuSr/ii13FfEgu3FZi3RYfAS0aU7uwq6kI8AG+JARt7cfJ7kE5OGhQV8xZKKle984dug=='
      , 'lYMsSIyF3rRS5jTEn0LHGs4yNYjpWCKz4xPl0wVB58ZXcdghBHh7akCyf4u4XzeqB2crXVYWLdb+yeIJ7eTiqhwagyvmdSPf9RvUM0V2GmWdlLZm5YPohL/1RsHtfdvao9jiCNCo1iwXZtu3JfXmLJsfIG6DOXfoGUSSdDoOv3tSCr4GYh748BEg5nQ100Q6pBnvvDM/LlZIUqDIYufEFh0+1cZSj7Y2mbCcKDXAAMmM5MoH2qOKrhceSvb8wGjVitaXYzNsZlFBCv8rJO7LB0Uj6WgyFlQaiLYZOahgvADOHa4r3bK55hj+lfSBwQU2ARvYPE74n9YSdi5M+Vtqyw=='
      , 'FOv0ZQ53Bf5dW5vD8mPsIt4xjfHUZAxkGQwGORF07tKyajyorNO5T5F2MaZUaRKrchoFgsOiAkxOufcUpQ3Z9fzrTaHA5u8+U0y714oEb6GbkpYYuaKT0Ojg1Fe57e37M3TezxRjghd/S+32zjtmG+pClAWVkFrwCUVC9PdW/OLW6iLuJxRwFARbQXmw01Q75oCPh8vFdzRQDwv11OrStFt2D5K5aoMiYZIH7FfW177gMTv/QHvFLlhUc7a5ERa4U/56tcoGKM39x0PqkY1iGJi3nTSgz77jfv8i0pahhqEDUfZA8x/RLhM4fb9C7C+Fc2tpRw0BsMSmXuIS8mYzwg=='
      , 'Ba6KeADSS0QhcPlDvDioKq4fM3lYndiEgwpXYenAQn2tvC0uRVUJBxfWjVuv1U+uaBcHwOiLmnyPyhtGXj9Y02nmDc0BPCzIwR2El4f+kGN+ITnfsLOheCq/CnUEVI287p3idplAKrdy0aGOr+gCqVtobUOy7JyuOKfNbGLGNmeIuVNq+F5m9yjnyNMpkogAzopl2o+2e7FnVmoNuITN3iyNDQn0Cwe9ZHGj/Zef1CeCpDYwp71E+mp12Ho6FiaRA+GV8eiaPPdBi6FG/w8Sc+CKqiXcu39aak6aGiLe0WYZILvnO5RqhndZ2mQ0O+mbWrpbRpv742CdPr3mlIMcAw=='
      , 'GatM4fACfuYBvAmRZvBAl3j0czuaqfyYTcyasQdYTugeG3Xi/sPt5Eqo0i9+QOB65Z6RQ7Qe5HX6OXIGeWJPuZcPL9c6Xcu4foL6vV0TG63J8jtQ35SjRmaTS+MYQCUW03F1JvN8IDiWPl+n/tezmC8XDodg/vHA0cKMgPDIEY2istxoQ6wlDUGw7BQ6xwBpE/tKLgqMVIzy3pOSlbVdMgKM6oFTJZ5WLtJLCWwhX9M1HMplE8xTuWE1OBrxvICc4G3srPcgBPYP3Ng/sIv08EF7EmnbS4bjV/AEILtmUgcHUwMPZK6pbblbYkAPFvrD7ELKtSSz42iuac9qD2FDxA=='
      , 'qA1r63HtOvV73sUGx7fUJVtwtZxEshDE268XT4BqyGxqokvCJRe79C9HdAS+Gi/Y8QxaREbaaT28A9VOALmTPvtGI2ivggEEwYcjWPMCnv9qARklddd5TlPAbtj/Xilbzrhj9UpC75EADnsDuOeOf0KydYGIeYNCnzCoRLsdLap40RAdm5W2M6K9z4ZOz8GbEo9bWq/AW1bg8YbeaBjDnrSgW4OHkcQM0zv+kFZMQGWD9F0x4lBzP1VqU08lJCqNIM49yCb/5mptSZlFv30QHttTto0gnpfyFhwkeNF3XTniNOQ8+9p/WwcOFGMvD1Evyd4JxcehmeQwW5KdPX164A=='
      , 'DAEXBumi7LhZ1yas4QqDSukki5Xq9s5p6Rgv0mkqbK9KuqHWU5AqMM/qR3nc0CTXn4tczMrNPo4E5lB2ndhyf40ywycRET+Cb4q2N7ki5IW+hgxGOWImJ1f0Atrwet/x67ciETyTlrXuo/d9IA7CRK9KS0JDFbidwulJA+RR9Tcupqj99ySbC+Is4ZwiBab0na819MZ/M06nguIt22dB5c1Oie2r4xiZ7Om4Z/7wgTlKLJCM0Y0Iy95QuEx7mZ0pDORR8g84TNX88+4v23y0l8H8zQUv2p3ML+SSg2Rsa3iHMOIsW6Hdpe397BT30JhTkY3hw0dtGekOKpXw4hlhKA=='
      , 'C31S/+USL0PHsYD895tAT42qQ8hzhlKBC0XVFW2tged3/KytmK+t7uWaxowfdPBNF1HVaXo8TrV5Vb0zboVzhe1QQH152KHiMR/kY5Fb5DnptxTT7wreMWV6KNyHck7SHyakLpBc3lHyJvx522AGf+V2kTrXU1MQGf2aUQ4P+cln8PeZQ3iVSGvMN4biZws9Bo6fKF9Q4La4ofHAn0NFqKv/fEBa6Q8BFeIjjcFugtKthCZKNX9Eh4Jhp6s3q7wllQmWUOCsSFULYLIU4vYlCDiKzCAgE11/KPizqLuhviuh13RIFKKa66xLU+AECtu4TJ4COPYym/Gux9M+iAP4rA=='
      , 'IyynekDkd676KBaAaTl8ETrs326pUIa9EPeoHGnqfQZW0zYvAy85zpSV1xtCgg9EvZFnGi7J8tR1PF8ENjMRwHmOebxMvZKDzYfLHizPdI0enBtyOC0cqipE1CHNeOr+eguWZ5iiTNq9BEElNQ4LpRF8Y/XjE5UhDNwbkBagOiBkz0Euwkn14oNvfWeq6MSIflqO1UH5QiQc5rRmLqVGblYxp9hNi+LjffIVrG6J6yqmacnbOWKKjT4qruUAGYtxrGVJgSdmqOGvsH4EIydS0yF7Qn7mTTw07S4WGviXKwrEZ9mBwfRmYaIjTaJPleENuwJx/sEgCA457OV5a4UsNA=='
    ];
    const challanges = body.auth_schemes[0].challenges.partial_password.positions;
    const answer = [3];
    answer[0] = passEnc[parseInt(challanges[0]) - 1];
    answer[1] = passEnc[parseInt(challanges[1]) - 1];
    answer[2] = passEnc[parseInt(challanges[2]) - 1];

    //this.encryptAnswer(body, pass[parseInt(challanges[0]) - 1])
    // answer[0] = this.encryptAnswer(body, pass[parseInt(challanges[0]) - 1]);
    // answer[1] = this.encryptAnswer(body, pass[parseInt(challanges[1]) - 1]);
    // answer[2] = this.encryptAnswer(body, pass[parseInt(challanges[2]) - 1]);
    //const a = new JSEncrypt();
    console.log(JSEncrypt());
    // encrypt.setPublicKey(publicKey);

    return answer;
  }

  static encryptAnswer(data, value) {
    const sessionId = data['auth_session_id'];
    const publicKey = data['public_key'];
    return this.encrypt(publicKey, `${sessionId}:${value}`);
  }

  static encrypt(publicKey, value) {
    if (!_.isString(value) && !_.isNumber(value)) {
      return undefined;
    }
    // console.log(window.JSEncrypt);
    // const encrypt = new JSEncrypt();
    // encrypt.setPublicKey(publicKey);
    // return encrypt.encrypt(value);
  }


  static callTokenAPI(data) {

    const body = "grant_type=client_credentials&scope=30";

    let authorizationHeader = JSON.stringify(
      this.buildChallengeResponse(data.userIdentity, data.challengeResponse, data.authData)
    );

    console.log(btoa(authorizationHeader));

    //authorizationHeader='eyJhdXRoX3Nlc3Npb25faWQiOiJkNWYwZjMzNS0yNzI3LTQ0MzktYTI2ZS1mN2JlOTA1YjNjNTkiLCJhdXRoX3NjaGVtZXMiOlt7InVzZXJfaWRlbnRpdHkiOnsidXNlcl9pZCI6IklOVFVTRVIzOCJ9LCJpZCI6ImEzMGJmNWUzLWNiNGUtNDkyNS1iZWUyLWE4YzdhZDNlOGRjMiIsImNoYWxsZW5nZV9yZXNwb25zZXMiOnsicGFydGlhbF9wYXNzd29yZCI6eyIxIjoiWHpMR1AvSkIveXNYVnBJR0J6cGNqY3ZQSFIyTDA1emprdFE4eGttVWZGdUs4L1FpOTZESnpzdE53SG95YjErNExYdUMrS3NSZ1ljbDZqd0FYNElWL050eS9aUXEyTUxUVHB5ZDVvakZWUXJucnRpRGJjem04YkpPdU9HMWZDN3R5aXBuK2ZVNHo1SE5Cc1NQU3VSbjFtNFpqa2ZXUUlyTTBTenpLaklKSDlVODl3aHlyZnNlaWZxQmJvRU9DNy81QUNMS0F6RDhjSnBaKysvbnU3R1RhczZkb3RwZjhldUtvMWZhZE42T1ZBNjhhTkU4Z2RaMWM3bVB4bG5XcHA5aHpReEdidkw2Y0gzNFRreDVkMHZRSElybTN3QjJpYjlNbUF1Uko0TTVaN3h5d1NKZUlYSG42QnVVTkF2cytmYnZFMmVwaWluZFJtTklieVViZm1uanpRPT0iLCI3IjoiRFhBMlR5M2JzdGNTOFdqaUlzVmN5d3FYeG5kdlJaeXZUeXJZeU5ZRDBFcnpWUTlzNzR4OGlUNnJZOFh0TzF3dzBnbk12UmlRWXFWWis0S2l3akg0enJISldGYm4xOHBqZkpRK1A0UTVNZHdOVXk3Q0kxL3hwY0JmU3o1T1Nadkg1UHRVV0xCUTZEM0F6VE1sajZHYW5ZREJHclVybW0wVjNVMWJjN2FRQ1pRMEF1Rm1aTk9Wc2JFZFRJdXlFd0FIelIwOGoxeGdPcVY1dUEyNk9SSHgwZnMrYjFFaTNrRWlKaG8weG1rZE1JMUk1STV2RHQvdUZDMHpiamhISmd2bFdreUxzN2s3ZVR4akJQNExFRjNFRGlLOWV1QnRvQ1R6bTYrcUE2NDRWM1c5bUZocGlqMmpJQlZvak9aQ2Q1a0tZTk44VDg5MzA4SlJxVTdTWldVRWhnPT0iLCIxMSI6IlJnMXF4RGlNcnRkN3l4U21LN2F2aEJOSjgvS1ZTbHZsYUprdVgrZzNEMXE0WHdsTXFLNno4RVNqcDlpa3hPc2NCaERITFM0QlJkcUtJeDZSeTBlcUlMYzVFOU9icjV6WGQ1aWFBRE9UOEdDcHpva0NtMU1aMEFPTEZaTkR6UTJCbHRLL0UwUjhhei9YbThoenhGamUvT1Z6Q0hHNE1wYXhIZDdnc2hxckVmOHBLVnBland5NjZnWDlLQUFKYmdEQVZiWS9TQVE3dmE1WkVjRTdlQ1RXT25QaGVKWTNJbUZLRitaaStuYmg4TkxGbENPYWIyVDk4YkU2dDRneWkyWVcrNlNHNU5IclM5S2NZcWczR0UxTHR5Z3Bac0xMUlh5dXpOa25NNWxMWG1Wall0MU5hL3ZzbHpCNi8rN0o1VEFOVE82b29KbGFPVnRLRFZFcUY5akhSdz09In0sInNlY3VyaXR5X3F1ZXN0aW9ucyI6eyJhbnN3ZXJzIjpbImFlYlJlYlppMVhMM2FTY3p5c2cvODRFWW1ZdE85bEErNWc5a2M4N2JMSGJYaHgyOXNVS0xRbFZ4ME42aWpGWmFtK29BYU83UHVIN2hwaXRRai9HY09CMmZEUjRoc2s3aXRJeHAxaFdXRXlzMUIydCtHVlZGRFJscUoxT1ltS09KNTdJZTJkV1lQTlVVYnlkYlB6WFBSa0hRaGpEV042eFV6V3FJR0hmbzh3SU45MmxsTGRhSnZzZEpJTHBLT0tNYWV5TmdHTTg2amozYU5qaWpoTm9NSm42eElBanQwcThrT0lPOXlkQWpLdEFYbS95S3FPVXVrS0Y2cE56Qy94YkdnUnI2d3dWZ2lqaWtHQjhTdnRDOHJCK0N6VHJvWUhLc1dKY050Q2JEQ21UK1R6dVJwYzZGS2RvbFdTVlJvTCtjTHozVjdVbnd2Vk9qSFVYenpTSGhCdz09Il19fX1dfQ=='

    makeAjaxCall({
      apiVersion: '0.8.0',
      method: 'POST',
      url: "https://my-dev.cybservices.co.uk/bpiInt3/banks/CB/auth/provider/oauth2/token",
      addAuthToken: false,
      authorizationHeader: `Basic ${authorizationHeader}`,
      contentType: 'application/x-www-form-urlencoded',
      body: body
    },
      (body, status) => {
        console.log('token body..', body);

      }, (error, status) => {
        console.log('error..', error);

      });


  }


  static buildChallengeResponse(userIdentity, challengeResponse, authData) {
    const authSchema = { userIdentity: { userInfo: { dateOfBirth: 'dob', postcode: 'post_code' } } };

    const response = {};
    response.auth_session_id = challengeResponse.auth_session_id;
    response.auth_schemes = [];

    if (!challengeResponse.auth_schemes) {
      return response;
    }

    const userIdentityValue = UserIdentityBuilder.build(userIdentity);

    _.each(challengeResponse.auth_schemes, scheme => {
      let challengeResponses = {};
      const nextChallengeResponse = _.partial(_.assign, {}, challengeResponses);

      if (scheme.challenges.partial_password) {
        const partialPassword = {};
        _.each(scheme.challenges.partial_password.positions, (pos, index) => {
          partialPassword[pos] = authData['partial-password'][index];
        });

        challengeResponses = nextChallengeResponse({ partialPassword });
      }

      if (scheme.challenges.security_questions) {
        const securityQuestions = {
          answers: _.clone(authData['security-questions'])
        };
        challengeResponses = nextChallengeResponse({ securityQuestions });
      }

      if (scheme.challenges.acn) {
        const acn = _.pick(authData.acn, ['access_code', 'sort_code', 'account_number']);
        challengeResponses = nextChallengeResponse({ acn });
      }

      if (scheme.challenges.debit_card) {
        const debitCard = _.pick(authData.debit_card, ['pan', 'sort_code', 'account_number']);
        challengeResponses = nextChallengeResponse({ debitCard });
      }

      if (scheme.challenges.otp) {
        const otp = _.clone(authData.otp.otp);
        challengeResponses = nextChallengeResponse({ otp });
      }

      const newData = _.assign({}, userIdentityValue, {
        id: scheme.id,
        challengeResponses
      });

      const newSchemeData = GenericMapperUtils.mapObject(newData, authSchema);

      response.auth_schemes.push(newSchemeData);
    });

    return response;
  }


}



const UserIdentityBuilder = {
	/**
	 * Responsible for building the entire userIdentity object.
	 *
	 * @param {string|UUID|object} source source to be mapped
	 *
	 * @return {Object} userIdentity object
	 *
	 * @example // username
	 *
	 * // 'username' => { userIdentity: { userName: 'username' } }
	 *
	 * // Unfortuently, the API doesn't comply to the SD, so we need to mangle our
	 * data and send userName as userId currently
	 *
	 * 'username' => { userIdentity: { userId: 'username' } }
	 *
	 * // UUID
	 *
	 * '8af6473a-42e0-40c3-ab66-7d156fabea93' =>
	  * { userIdentity: { userId: '8af6473a-42e0-40c3-ab66-7d156fabea93' } }
	 *
	 * // User Info
	 *
	 * { firstName: 'firstName', ...} =>
	 * { userIdentity: { userInfo: { firstName: 'firstName', ... } } }
	 *
	 */
  build: source => _.flow(UserIdentityBuilder.buildBody, UserIdentityBuilder.userIdentity)(source),

	/**
	 * Responsble for building the body of the userIdentity object.  Runs conditions
	 * to assert what we are dealing with, and delegates to the appropriate mapper method
	 *
	 * @param {String|UUID|Object} source source to be mapped
	 *
	 * @return {Object} mapped object matches the source
	 *
	 */
  buildBody: source => {
    if (UserIdentityBuilder.isUUID(source)) {
      return UserIdentityBuilder.fromUserId(source);
    }

    if (_.isString(source)) {
      return UserIdentityBuilder.fromUsername(source);
    }

    if (_.isPlainObject(source)) {
      return UserIdentityBuilder.fromUserInfo(source);
    }

    throw new Error(`source invalid source: ${source}`);
  },

	/**
	 * Builds a userName object to later be sent to the UI.  We are using
	 * the paramater name to ensure propery name, so we can send it correctly
	 * to the API.  It will later be translated to user_name based on camelcase -> snakecasing
	 * transformer used within the mapper.
	 *
	 * @param {String} userName username to be user to create the username object
	 *
	 * @return {Object} new userName object
	 *
	 * @example // 'username' => {userName: 'username'}
	 *
	 * 'username' => {userId: 'username'}
	 *
	 * @ticket DYB-19034
	 */
  fromUsername: userName => {
    if (!_.isString(userName)) {
      throw new Error('userName must be a string');
    }

    return { userId: userName };
  },

	/**
	 * Builds the userIdentity object.
	 *
	 * @param {Object} userIdentity userIdentity object to be used to contruct the userIdentity
	 * object required by the API
	 *
	 * @return {Object} Correctly constructed userIdentity
	 *
	 * @example userIdenty => {userIdentity: userIdentity}
	 *
	 */
  userIdentity: userIdentity => ({ userIdentity }),

	/**
	 * Builds the userId object.
	 *
	 * @param {Object} userId userIdentity object to be used to contruct the userId
	 * object required by the API
	 *
	 * @return {Object} Correctly constructed userId
	 *
	 * @example '8af6473a-42e0-40c3-ab66-7d156fabea93' =>
	 * {userId: '8af6473a-42e0-40c3-ab66-7d156fabea93'}
	 *
	 */
  fromUserId: userId => {
    if (!UserIdentityBuilder.isUUID(userId)) {
      throw new Error(`${JSON.stringify(userId)} is not a UUID`);
    }
    return ({ userId });
  },

	/**
	 * Builds the UserInfo object.
	 *
	 * @param {Object} userId userIdentity object to be used to contruct the UserInfo
	 * object required by the API
	 *
	 * @return {Object} Correctly constructed UserInfo
	 *
	 * @example { firstName: 'firstName', ...} => { userInfo: { firstName: 'firstName', ... } }
	 *
	 */
  fromUserInfo: userInfo => ({ userInfo }),

	/**
	 * Helper method for matching UUIDs
	 *
	 * @param {String} source userIdentity object to be used to contruct the fromUserInfo
	 * object required by the API
	 *
	 * @return {Boolean} True if source matches UUID regex, false otherwise
	 */
  isUUID: source => /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/.test(source),
};

export default loginApi;
