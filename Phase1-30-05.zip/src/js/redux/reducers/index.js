import { combineReducers } from 'redux';

import user,* as login from './loginReducer';
import customers from './customerReducer';


const rootReducer = combineReducers({
  user,
  customers
});


export const getAuthToken = () => {
    return login.getAuthToken();
};

export default rootReducer;
