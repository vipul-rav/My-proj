import * as types from '../../shared/constant/actionTypes';

let authToken = {};

const initialState = {
  user: {
    isAuth: false,
    authToken: authToken,
    userIdentity: {}
  }
};


export const getAuthToken = () => {
  return authToken;
};


const loginReducer = (state = initialState.user, action) => {
  const newState = Object.assign({}, state);
  switch (action.type) {
    case types.LOGIN_SUCCESS:
      // newState.isAuth=action.data;
      newState.isAuth = true;
      newState.authToken = { "userId": "sdsadasd" };
      authToken = { "userId": "sdsadasd" };
      return newState;
    case types.LOGIN_FAILURE:
      newState.isAuth = false;
      return Object.assign({}, newState);
    default:
      return state;
  }
};

export default loginReducer;