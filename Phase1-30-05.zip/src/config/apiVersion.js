export default window.apiVersion = {
    authServices:'0.8.0',
    customerListService:"0.8.0",
    customerOptedService:"0.8.0",
    customerDetailService:"0.8.0",
    customerHistoryService:"0.8.0",
    customerProductsService:"0.8.0"
}
