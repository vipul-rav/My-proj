export default window.stubConfig =
    {
        login: "login.json",
        customerList: "customers.json"
    };