const content = {
    headerText: 'Header'
};

export default content;