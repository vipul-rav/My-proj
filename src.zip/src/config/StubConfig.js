export default window.stubConfig =
    {
        login: "login.json",
        customerList: "customers.json",
        customerDetailsStub: "customerDetails-",
        customerProductStub: "products-",
        customerHistoryStub: "CustomerHistoryDetails-",
        customerServiceStub: "CustomerServiceDetail-"
    };