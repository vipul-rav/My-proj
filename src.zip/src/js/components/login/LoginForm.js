/**
	* @module  LoginForm
	*/
import React from 'react';
import PropTypes from 'prop-types';


class LoginForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLogin: false,
      id: '',
      password: ''
    };
    this._redirectToDashboard = this._redirectToDashboard.bind(this);
    this.handleChangeId = this.handleChangeId.bind(this);
    this.handleChangePwd = this.handleChangePwd.bind(this);
  }

  _redirectToDashboard() {
    this.props.handleSubmit(this.state.Id, this.state.password);
  }
  handleChangeId(e) {
    this.setState({ Id: e.target.value });
  }
  handleChangePwd(e) {
    this.setState({ password: e.target.value });
  }
  render() {
    return (
      <div>
        <div className="container">
          <div className="row" >
            <div className="col-md-offset-3 col-md-6 col-md-offset-3">
              <div className="contactArea">
                <h3 className="text-center">Login</h3>
                <label>{this.props.errorMsg}</label>
                <div className="row">
                  <div className="col-md-4">
                    <label className="login-label">User Id</label>
                  </div>
                  <div className="col-md-8 form-group">
                    <input
                      type="Id"
                      name="Id"
                      defaultValue={this.state.id}
                      onChange={this.handleChangeId}
                      placeholder="User Id"
                      title="Enter your User Id"
                    />
                  </div>
                  <br />
                  <div className="col-md-4">
                    <label className="login-label">Password</label>
                  </div>
                  <div className="col-md-8 form-group">
                    <input
                      type="password"
                      name="password"
                      defaultValue={this.state.password}
                      onChange={this.handleChangePwd}
                      placeholder="Password"
                      title="Type a strong <p></p>assword: aBC_123^"

                    />
                  </div>
                </div>
                <br />
                <button type="submit" className="btn form-button-margin" disabled={this.state.id.length == 0 && this.state.password.length == 0} onClick={this._redirectToDashboard}>Login</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );

  }
}

LoginForm.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  errorMsg: PropTypes.string.isRequired
};

export default LoginForm;