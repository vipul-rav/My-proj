/**
	* @module  Login Home
	*/
import React from 'react';
import PropTypes from 'prop-types';
import LoginForm from './LoginForm';

class LoginHome extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            error: ''
        };
    }

    render() {
        return (
            <div>
                <LoginForm handleSubmit={this.props.handleSubmit} errorMsg={this.state.error} />
            </div>
        );
    }
}

LoginHome.propTypes = {
    handleSubmit: PropTypes.func.isRequired
};



export default LoginHome;
