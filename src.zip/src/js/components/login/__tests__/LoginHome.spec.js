import React from 'react';
import { shallow, mount } from 'enzyme';
import LoginHome from '../LoginHome';
import expect from 'expect';

const props = {
    handleSubmit: jest.fn(),
    errorMsg: ""
};


describe('Login Home components', () => {

    it('should set props from state', () => {

        const Wrapper = mount(<LoginHome {...props} />);
        Wrapper.setState({ error: "test" });
        const loginForm = Wrapper.find('LoginForm');

        expect(loginForm.props().errorMsg).toBe(Wrapper.state().error);
    });

    it('should call handle submit', () => {

        const Wrapper = mount(<LoginHome {...props} />);
        const loginForm = Wrapper.find('LoginForm');
        loginForm.props().handleSubmit();
        expect(Wrapper.props().handleSubmit.mock.calls.length).toBe(1);
    });


});