import React from 'react';
import PropTypes from 'prop-types';
import { Link, NavLink } from 'react-router-dom';
import { DropdownButton, MenuItem } from 'react-bootstrap';
import _ from 'lodash';
import headerLogo from '../../../assets/images/logo.png';
import loginHeader from '../../../assets/images/login-header.jpg';

const Header = (auth) => {

  return (
    <header className="header">
      <div style={{ "float": "right" }}>
        {auth.isAuth && <Link to="/">Logout</Link>}
      </div>
    </header>
  );
};


export default Header;
