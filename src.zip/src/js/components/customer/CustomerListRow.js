/**
	* @module  CustomerListRow
	*/

import React, { PropTypes } from 'react';
import { Link } from 'react-router';

const CustomerListRow = ({ customer, onClick }) => {
  return (
    <tr >
      <td></td>
      <td><label style={{'cursor': 'hand'}} onClick={onClick.bind(this, customer.id)} > {customer.customer_number} </label></td>
      <td>{customer.name}</td>
      <td>{customer.address}</td>
      <td>{customer.postcode}</td>
    </tr>
  );
};

CustomerListRow.propTypes = {
  customer: PropTypes.object.isRequired,
  onClick: PropTypes.func.isRequired
};

export default CustomerListRow;
