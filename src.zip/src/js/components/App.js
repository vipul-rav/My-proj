// This component handles the App template used on every page.
import React from 'react';
import PropTypes from 'prop-types';
import Header from './common/Header';
import { connect } from 'react-redux';
import { Route, Redirect, withRouter } from 'react-router-dom';
import HomePage from './home/HomePage';
import LoginHome from './login/LoginHome';
import content from '../../static/content';
import { bindActionCreators } from 'redux';
import * as LoginAction from '../redux/actions/LoginAction';


class App extends React.Component {
  constructor(props, context) {
    super(props, context);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleSubmit(id, password) {
    this.props.actions.login(id, password);
  }

  render() {
    return (
      <div className="container-fluid1">

        {this.props.user.isAuth
          ? <HomePage {...this.props} />
          : <LoginHome handleSubmit={this.handleSubmit} />}
      </div>
    );
  }
}


App.propTypes = {
  actions: PropTypes.object.isRequired,
  user: PropTypes.object.isRequired,
  history: PropTypes.object.isRequired
};

App.defaultProps = {
  showHeader: true,
  content: content
};

function mapStateToProps(state, ownProps) {
  return {
    user: state.user
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(LoginAction, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
