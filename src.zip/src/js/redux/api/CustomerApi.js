/**
	* @module CustomerApi
	*/

import { makeAjaxCall } from '../../shared/helpers';
import { ApiBaseUrl, isStub, stubConfig } from '../../../config/ServiceConfig';
const _getPersonList = '/banks/{bank-id}/accounts/default';
const _getCustomerDetails = 'banks/{bank_id}/customers/{customer_id}';
const _getCustomerProduct = 'banks/{bank_id}/customers/{customer_id}';
const _getCustomerHistory = 'banks/{bank_id}/customers/{customer_id}';
const _getCustomerService = 'banks/{bank_id}/customers/{customer_id}';

let customers = [];

class CustomerApi {
  /**To display Customer List on Customer Search */
  static getAllCustomers(bankname, last_name, initials, postcode, dispatch, success, failure) {

    let url = ApiBaseUrl() + _getPersonList;
    if (isStub)
      url = ApiBaseUrl() + stubConfig.customerList;

    const body = {
      "last_name": last_name,
      "initial": initials,
      "postcode": postcode
    };

    makeAjaxCall({
      apiVersion: 0.1,
      method: isStub ? 'GET' : 'POST',
      url,
      addAuthToken: true,
      body: body

    }, (body, status) => {
      dispatch(success(body));
    }, (error, status) => {
      dispatch(failure([]));
    });
  }


  /**To display Customer Information on Customer Summary */
  static getCustomerDetails(id, dispatch, success, failure) {

    let url = ApiBaseUrl() + _getCustomerDetails;
    if (isStub)
      url = ApiBaseUrl() + stubConfig.customerDetailsStub + id + ".json";

    makeAjaxCall({
      apiVersion: 0.1,
      method: 'GET',
      url,
      addAuthToken: true

    }, (body, status) => {
      dispatch(success(body));
    }, (error, status) => {
      dispatch(failure([]));
    });
  }


  /**To display Products on Customer Summary */
  static getCustomerProduct(id, dispatch, success, failure) {

    let url = ApiBaseUrl() + _getCustomerProduct;
    if (isStub)
      url = ApiBaseUrl() + stubConfig.customerProductStub + id + ".json";

    makeAjaxCall({
      apiVersion: 0.1,
      method: 'GET',
      url,
      addAuthToken: true

    }, (body, status) => {
      dispatch(success(body));
    }, (error, status) => {
      dispatch(failure([]));
    });
  }


  /**To display Customer History on Customer Summary */
  static getCustomerHistory(id, dispatch, success, failure) {
    let url = ApiBaseUrl() + _getCustomerHistory;
    if (isStub)
      url = ApiBaseUrl() + stubConfig.customerHistoryStub + id + ".json";

    makeAjaxCall({
      apiVersion: 0.1,
      method: 'GET',
      url,
      addAuthToken: true

    }, (body, status) => {
      dispatch(success(body));
    }, (error, status) => {
      dispatch(failure([]));
    });
  }

  /**To display Services on Customer Summary */
  static getCustomerService(id, dispatch, success, failure) {
    let url = ApiBaseUrl() + _getCustomerService;
    if (isStub)
      url = ApiBaseUrl() + stubConfig.customerServiceStub + id + ".json";

    makeAjaxCall({
      apiVersion: 0.1,
      method: 'GET',
      url,
      addAuthToken: true

    }, (body, status) => {
      dispatch(success(body));
    }, (error, status) => {
      dispatch(failure([]));
    });
  }


}
export default CustomerApi;

