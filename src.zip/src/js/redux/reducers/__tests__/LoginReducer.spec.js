import reducer from '../LoginReducer';
import * as login from '../../reducers';
import * as types from '../../../shared/constant/ActionTypes';
import expect from 'expect';


let authToken = {};

describe('Login reducer', () => {
    it('should return the initial state', () => {
        expect(
            reducer(undefined, {})
        ).toEqual(
            {
                authToken: authToken,
                isAuth: false,
                userIdentity: {}
            }
            );
    });

    it('should handle Login success', () => {
        expect(
            reducer({}, {
                type: types.LOGIN_SUCCESS,
                data: {
                    "userId": "test"
                }
            })
        ).toEqual(
            {
                authToken: { "userId": 'test' },
                isAuth: true
            }
            );
    });

    it('should handle Login Failure', () => {
        expect(
            reducer({}, {
                type: types.LOGIN_FAILURE
            })
        ).toEqual(
            {
                isAuth: false
            }
            );
    });

    it('should handle reset authentication token', () => {
        expect(
            reducer({}, {
                type: types.RESET_AUTH
            })
        ).toEqual(
            {
                user: {
                    isAuth: false,
                    authToken: authToken,
                    userIdentity: {}
                }
            }
            );
    });


    it('should handle reset authentication token', () => {
       
        expect(login.getAuthToken()).toEqual({ "userId": 'test' });
    });




});