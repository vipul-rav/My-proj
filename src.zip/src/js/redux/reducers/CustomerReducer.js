/**
	* @module CustomerReducer
	*/
import * as types from '../../shared/constant/ActionTypes';

const initialState = {
  customers: [],
  customerDetail: {},
  customerProduct: {},
  customerHistory: [],
  customerService: [],
  customerDetailFlag: false,
  customerProductFlag: false,
  customerHistoryFlag: false,
  customerServiceFlag: false

};

export default function CustomerReducer(state = initialState, action) {
  // const newstate = Object.assign({}, [...state]);
  switch (action.type) {

    /**For displaying Customer List */
    case types.SEARCH_SUCCESS:
      return Object.assign({}, state, { customers: action.data });

    /**For displaying Customer Information on Customer Summary */
    case types.CUSTOMERDETAIL_SUCCESS:
      return Object.assign({}, state, { customerDetail: action.data, customerDetailFlag: true });

    /**For displaying Products on Customer Summary */
    case types.CUSTOMER_PRODUCT_SUCCESS:
      return Object.assign({}, state, { customerProduct: action.data, customerProductFlag: true });

    /**For displaying Customer History on Customer Summary */
    case types.CUSTOMER_HISTORY_SUCCESS:
      return Object.assign({}, state, { customerHistory: action.data, customerHistoryFlag: true });

    /**For displaying Services on Customer Summary */
    case types.CUSTOMERSERVICE_SUCCESS:
      return Object.assign({}, state, { customerService: action.data, customerServiceFlag: true });
    /**For displaying Services on Customer Summary */
    case types.RESET_CUSTOMERS:
      return initialState;

    default:
      return state;

  }
}
