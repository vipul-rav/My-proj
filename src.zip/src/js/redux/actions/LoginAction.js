/**
	* @module LoginAction
	*/

import * as types from '../../shared/constant/ActionTypes';
import LoginApi from '../api/LoginApi';


/**On successful Customer Login*/
export function loginsuccess(data) {
  return { type: types.LOGIN_SUCCESS, data };
}
export function loginfailure(result) {
  return { type: types.LOGIN_FAILURE, data: result };
}
export function login(Id, password) {
  return function (dispatch) {
    try {
      LoginApi.loginDetail(Id, password, dispatch, loginsuccess, loginfailure);
    } catch (error) {
      throw (error);
    }
  };
}
export function resetAuthToken() {
  return function (dispatch) {
    return { type: types.RESET_AUTH };
  };
}


