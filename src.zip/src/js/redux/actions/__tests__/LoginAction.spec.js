import * as actions from '../LoginAction'
import * as types from '../../../shared/constant/ActionTypes';
import expect from 'expect';

describe('User login into TB ', () => {
    it('should call success in case of valid user', () => {
        const text = {
            "userId": "test",
            "bankId": "cb"
        }
        const expectedAction = { "data": "agent", "type": "LOGIN_SUCCESS" }

        expect(actions.loginsuccess('agent')).toEqual(expectedAction)
    })

    it('should call failure in case of invalid user', () => {
        const text = {
            "userId": "test",
            "bankId": "cb"
        }
        const expectedAction = { data: [], type: 'LOGIN_FAILURE' }

        expect(actions.loginfailure([])).toEqual(expectedAction)
    })

    it('shouild reset if logout/error', () => {
        const text = {
            "userId": "test",
            "bankId": "cb"
        }
        const expectedAction = () => {};

        expect(actions.resetAuthToken()).toEqual(expectedAction)
    })

    it('should login with credential', () => {
        const text = {
            "userId": "test",
            "bankId": "cb"
        }
        const expectedAction = { "data": "agent", "type": "RESET_AUTH" }

        expect(actions.login('agent', 'agent')).toEqual(expectedAction)
    })
})