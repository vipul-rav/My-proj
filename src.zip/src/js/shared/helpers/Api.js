import { envBankConfig, general } from '../../../config/ServiceConfig';
import BrowserUtils from '../utils/BrowserUtils';
import * as session from './Persist';
import * as login from '../../redux/reducers';

const getClientContext = () => {
  // Default object
  const clientContext = {
    client: {},
    env: {
      // jscs: disable
      // jshint ignore:start
      platform_version: BrowserUtils.getBrowserVersion(),
      // jshint ignore:end
      // jscs: enable
      make: BrowserUtils.getPlatform(),

      locale: BrowserUtils.getUserLocale(),
      // For Payment Services BOW-36
      model: 'x86_64',
      geo_location: {
        longitude: -122.406417,
        latitude: 37.785834
      },
      device_lock_enabled: true,
      screen_size: {
        width: 1024,
        height: 768
      },
      device_name: 'iPad%20Simulator'
    }
  };

  // Appstore will contain the session id (generated uuid)
  // so that it doesn't change through-out
  clientContext.client['user_tracking_id'] = session.getState('sessionId');
  clientContext.client['app_title'] = general.documentTitle;
  clientContext.client['app_package_name'] = general.appPackageName;
  clientContext.client['app_version_code'] = general.version;
  clientContext.client['app_version_name'] = general.versionName;
  clientContext.env.platform = general.platform;

  return JSON.stringify(clientContext);
};

function replaceBankId(url) {
  return url.replace('{bank-id}', envBankConfig.bankId)
}

/**
 * Make an API call.
 *
 * @param  {Object} callData 		All data about the call.
 * @param {Function} onSuccess 	Optional. No default. Callback when API call completes successfully.
 * @param {Function} onFail 	Optional. Default navigates user to error page. Callback when the API call fails.
 */

export const makeAjaxCall = async (callData, onSuccess, onFail) => {

  const data = callData;

  if (!data.apiVersion) {
    console.warn('API call requires a version for endpoint', data.url);
  }

  const contentType = data.contentType === 'N' ? null : data.contentType || 'application/json';

  data.url = replaceBankId(data.url);

  const header =
    {
      'Accept': 'application/json',
      'x-bpi-version': data.apiVersion,
      'x-bpi-service-context': general.authentication.context,
      'Content-Type': 'application/json'
    };

  if (contentType !== null) {
    header['Content-Type'] = contentType;
  }

  // Auth token present?
  if (data.addAuthToken) {
    const authToken = data.authToken;
    if (authToken) {
      header['Authorization'] = `Bearer ${authToken}`;
    }

  } else if (data.authorizationHeader) {
    header['Authorization'] = data.authorizationHeader;
  }

  header['x-bpi-client-context'] = getClientContext();


  if (data) {

    try {
      const response = await fetch(data.url, {
        method: data.method,
        headers: header,
        body: data.body != undefined ? data.body : null
      })

      const result = await response.json();

      if (response.ok) {
        onSuccess(result, 1);
      } else {
        onFail(result, 0);
      }

    } catch (error) {
      console.log(error);
      if (onFail)
        onFail(error, 0);

    }
  }
}

