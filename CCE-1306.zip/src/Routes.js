import React from 'react';
import { Route, IndexRoute } from 'react-router';
import App from './js/components/App';
import HomePage from './js/components/home/HomePage';
import Header from './js/components/common/Header';
import LoginHome from './js/components/login/LoginHome';
import CustomerSearch from './js/components/customer/CustomerSearch';
import Error from './js/components/common/Error';
import CustomerSummary from './js/components/customer/CustomerSummary';



const Routes = () =>
  <div>
    <Header />
    <Route exact path="/" component={HomePage} />
    <Route path="/home" component={HomePage} />
    <Route path="/customerSearch" component={CustomerSearch} />
    <Route path="/error" component={Error} />
    <Route path="/customerSummary" component={CustomerSummary} />

  </div>;

export default Routes;