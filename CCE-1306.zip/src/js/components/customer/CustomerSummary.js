/**
	* @module  CustomerSummary
	*/
import React, { PropTypes, Component } from 'react';
import { Link } from 'react-router';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import CustomerInformation from './CustomerInformation';
import CustomerServices from './CustomerServices';
import CustomerHistory from './CustomerHistory';
import HomePage from '../home/HomePage';
import CustomerProducts from './CustomerProducts';
import VerifyModal from './VerifyModal';
import * as customerAction from '../../redux/actions/CustomerAction';

class CustomerSummary extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isBack: false,
            customerDetailFlag: 'false',
            customerProductFlag: 'false',
            customerHistoryFlag: 'false',
            customerServiceFlag: 'false'

        };
        this._BackToHomePage = this._BackToHomePage.bind(this);
    }

    /** To go back to HomePage*/
    _BackToHomePage() {
        this.props.actions.resetCustomers();
        this.props.history.push('/');
    }
   
    render() {

        return (
            <div className="container-fluid page-style">
                {
                    this.props.customerDetails.id === undefined ? <div>Loading....</div>
                        :
                        <div>
                            {!this.state.isBack ?
                                <div>
                                    <VerifyModal modalShow={this.props.show} history={this.props.history} OnfailClick={this._BackToHomePage}/>
                                    <button type="button" className="btn page-margin" onClick={this._BackToHomePage}>Back To Dashboard</button>
                                    <div className="row">
                                        <div className="col-sm-6">
                                            <div className="container">
                                                <h4>Customer Information</h4>
                                                {this.props.customerDetailFlag === false ? <div>Loading....</div>
                                                    :
                                                    <CustomerInformation customerDetail={this.props.customerDetails} />
                                                }
                                            </div>
                                        </div>
                                        <div className="col-sm-6">
                                            <div className="container">
                                                <h4>Customer History</h4>
                                                {this.props.customerHistoryFlag === false ? <div>Loading....</div>
                                                    :
                                                    <CustomerHistory customerHistory={this.props.customerHistory} />
                                                }
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row">
                                        <div className="col-sm-6">
                                            <div className="container">
                                                <h4>Customer Services</h4>
                                                {this.props.customerServiceFlag === false ? <div>Loading....</div>
                                                    :
                                                    <CustomerServices customerService={this.props.customerService} />
                                                }
                                            </div>
                                        </div>
                                        <div className="col-sm-6">
                                            <div className="container">
                                                <h4>Products</h4>
                                                {this.props.customerProductFlag === false ? <div>Loading....</div>
                                                    :
                                                    <CustomerProducts customerProduct={this.props.customerProduct} />
                                                }
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                :
                                <HomePage />
                            }
                        </div>
                }
            </div>

        );
    }
}
CustomerSummary.propTypes = {
    customerDetails: PropTypes.object.isRequired,
    customerProduct: PropTypes.object.isRequired,
    customerHistory: PropTypes.array.isRequired,
    customerService: PropTypes.array.isRequired,
    customerDetailFlag: PropTypes.bool,
    customerProductFlag: PropTypes.bool,
    customerHistoryFlag: PropTypes.bool,
    customerServiceFlag: PropTypes.bool,
    history: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired
};

function mapStateToProps(state, ownProps) {
    return {
        customerDetails: state.customers.customerDetail,
        customerProduct: state.customers.customerProduct,
        customerHistory: state.customers.customerHistory,
        customerService: state.customers.customerService,
        customerDetailFlag: state.customers.customerDetailFlag,
        customerProductFlag: state.customers.customerProductFlag,
        customerHistoryFlag: state.customers.customerHistoryFlag,
        customerServiceFlag: state.customers.customerServiceFlag

    };
}
function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(customerAction, dispatch)
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(CustomerSummary);