/**
	* @module  VerifyModal
	*/

import React, { PropTypes, Component } from 'react';
import { Link } from 'react-router';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import HomePage from '../home/HomePage';
import Modal from 'react-bootstrap/lib/Modal';

class VerifyModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            show: true,
            onfail: false
        };
        this.close = this.close.bind(this);
        this.open = this.open.bind(this);
        this._OnfailClick = this._OnfailClick.bind(this);
    }
    close() {
        this.setState({ showModal: false });
    }

    open() {
        this.setState({ showModal: true });
    }
    /** on click on fail redirect to search page */
    _OnfailClick() {
        this.props.OnfailClick();
    }

    render() {
        let close = () => this.setState({ show: false });
        return (
            <div>

                <div>
                    <Modal
                        show={this.state.show}
                        onHide={close}
                        container={this}
                        aria-labelledby="contained-modal-title"
                        onClick={this._OnfailClick}
                    >
                        <Modal.Header closeButton>
                            <Modal.Title id="contained-modal-title">Verify Customer- Name and Address Check</Modal.Title>
                        </Modal.Header>

                        <Modal.Body>
                            <p>Please confirm the following</p>
                            <ul>
                                <li>Full Name</li>
                                <li>1st line of Address(Street Number/Name)</li>
                                <li>Full Postcode</li>
                            </ul>
                            <p> Did the caller pass the fullname, address and postcode check?</p>
                            <br />
                        </Modal.Body>
                        <Modal.Footer>
                            <button type="button" className="btn page-margin" onClick={close}>Pass</button>
                            <button type="button" className="btn page-margin" onClick={this._OnfailClick}>Refer/Fail</button>
                            <button type="button" className="btn page-margin" onClick={close}>Bypass</button>
                            <button type="button" className="btn page-margin" onClick={close}>Cancel</button>
                        </Modal.Footer>
                    </Modal>
                </div>
            </div>


        );
    }
}
VerifyModal.propTypes = {
     /** modalShow: PropTypes.object.isRequired,*/
    history: PropTypes.object.isRequired,
    OnfailClick:PropTypes.object.isRequired
};


export default VerifyModal;