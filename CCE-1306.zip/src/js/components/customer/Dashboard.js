/**
	* @module  Dashboard
	*/

import React,{Component} from 'react';
import { Link } from 'react-router';
import ButtonToolbar from 'react-bootstrap/lib/ButtonToolbar';
import Button from 'react-bootstrap/lib/Button';
import CustomerSearch from './CustomerSearch';
import Panel from 'react-bootstrap/lib/Panel';


export default class Dashboard extends Component {
   constructor(props) {
    super(props);
    this.state = {
      data: '',
      isSearch:false
    };
    this._customerSearchOnClick = this._customerSearchOnClick.bind(this);
  }

/** Search button func */
  _customerSearchOnClick() {
 
   this.setState({isSearch:true});
 }
  

  render() {
    return (
      
      <div>
        {!this.state.isSearch ?
        <div>
          <Panel>
        <strong><h3> Dashboard Page </h3></strong>
        <Button onClick={this._customerSearchOnClick} bsStyle="primary" >Customer Search</Button>
        <h4>{this.state.data}</h4>
        </Panel>
        </div>
        :
        <CustomerSearch/>
        }
      </div>
    );
  }
}


