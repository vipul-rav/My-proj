/**
	* @module  CustomerListRow
	*/

import React, {PropTypes} from 'react';
import {Link} from 'react-router';

const CustomerListRow = ({customer,onClick}) => {
  return (
     <tr onClick={onClick.bind(this,customer.id)}>
      <td></td>
      <td>{customer.customer_number}</td>
      <td>{customer.name}</td>
      <td>{customer.address}</td>
      <td>{customer.postcode}</td>
    </tr>
  );
};

CustomerListRow.propTypes = {
  customer: PropTypes.object.isRequired,
  onClick: PropTypes.func.isRequired
};

export default CustomerListRow;
