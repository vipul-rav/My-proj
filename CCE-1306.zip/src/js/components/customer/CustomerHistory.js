/**
	* @module  CustomerHistory
	*/

import React, { PropTypes } from 'react';
import Form from 'react-bootstrap/lib/Form';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as customerAction from '../../redux/actions/CustomerAction';

class CustomerHistory extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <div className="table-scroll">
                <table className="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Location</th>
                            <th>Rating</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.customerHistory.map(history => {
                        return (
                            <tr key={history.date}>
                                <td>{history.date}</td>
                                <td>{history.location}</td>
                                <td>{history.rating}</td>
                                <td>{history.description}</td>
                            </tr>);
                        })
                        }
            </tbody>
                </table>
            </div>
        );
        
    }
}
CustomerHistory.propTypes = {
    customerHistory: PropTypes.array.isRequired
};

export default CustomerHistory;