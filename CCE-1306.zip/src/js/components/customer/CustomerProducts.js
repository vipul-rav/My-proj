/**
	* @module  CustomerProducts
	*/
import React, { PropTypes } from 'react';
import Form from 'react-bootstrap/lib/Form';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as customerAction from '../../redux/actions/CustomerAction';
import _ from 'lodash';

class CustomerProducts extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    }
 /** spliting of acc number */
    getAccountNumber(number) {

        const accountNumber = _.split(number, '-');
        return accountNumber[1];
    }
/** spliting of sort code */
    getSortCode(number) {

        const accountNumber = _.split(number, '-');
        return accountNumber[0];
    }

    render() {

        return (
            <table className="table table-bordered" style={{ "width": "50%" }}>
                <thead>
                    <tr>
                        <th>Account Code</th>
                        <th>Sort Code</th>
                        <th>Account Number</th>
                        <th>Product Class</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        this.props.customerProduct.accounts.map(account => {
                            return (<tr  key={account.product.code}>
                                <td>{account.product.code}</td>
                                <td>{this.getSortCode(account.number)}</td>
                                <td>{this.getAccountNumber(account.number)}</td>
                                <td>{account.product.name}</td>
                            </tr>);
                        })

                    }
                </tbody>
            </table>
        );
    }
}
CustomerProducts.propTypes = {
    // CustomerProduct: PropTypes.object.isRequired,
    customerProduct: PropTypes.object.isRequired
};

function mapStateToProps(state, ownProps) {
    return {

    };
}
function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(customerAction, dispatch)
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(CustomerProducts);