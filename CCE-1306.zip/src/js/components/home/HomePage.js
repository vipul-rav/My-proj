/**
	* @module  Dashboard
	*/
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import ButtonToolbar from 'react-bootstrap/lib/ButtonToolbar';
import Button from 'react-bootstrap/lib/Button';
import CustomerSearch from '../customer/CustomerSearch';
import Panel from 'react-bootstrap/lib/Panel';
import LoginHome from '../login/LoginHome';
import { bindActionCreators } from 'redux';
import * as LoginAction from '../../redux/actions/LoginAction';
import PropTypes from 'prop-types';

class HomePage extends React.Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      data: '',
      isSearch: false
    };

    this._customerSearchOnClick = this._customerSearchOnClick.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
/** onclick func to goto search page  */
  _customerSearchOnClick() {
    this.props.history.push('/customerSearch');

  }

  handleSubmit(id, password) {
    this.props.actions.login(id, password);
  }


  render() {
    return (
      <div>
        {this.props.user.isAuth
          ? <div>
            <strong><h3> Dashboard Page </h3></strong>
              <Panel className="panel-style" onClick={this._customerSearchOnClick}>
               <h3 >Customer Search</h3>
                  <h4>{this.state.data}</h4>
                </Panel>

                <Panel className="panel-style">
                  <h3>Person Search</h3>
                </Panel>

                <Panel className="panel-style">
                  <h3>Products</h3>
                </Panel>
          </div>
          : <LoginHome {...this.props} handleSubmit={this.handleSubmit} />}

      </div>
    );
  }
}

const mapStateToProps = state => ({ user: state.user });


function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(LoginAction, dispatch)
  };
}

HomePage.propTypes = {
    actions: PropTypes.object.isRequired,
    user: PropTypes.object.isRequired,
    history: PropTypes.object.isRequired

};



export default connect(mapStateToProps, mapDispatchToProps)(HomePage);