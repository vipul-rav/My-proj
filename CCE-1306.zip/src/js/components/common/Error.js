import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as loginAction from '../../redux/actions/LoginAction';

class Error extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data: '',
            isSearch: false,
            last_name: ''
        };
        this.errorClick = this.errorClick.bind(this);
    }
    errorClick() {
        this.props.actions.resetAuthToken();
        this.props.history.push('/');
    }
    render() {
        return (

            <nav className="navbar navbar-toggleable-md navbar-inverse fixed-top">
                <div className="collapse navbar-collapse">
                    There is some error occured.
                <a className="active" onClick={this.errorClick}>Login</a>
                </div>
            </nav>

        );
    }
}

function mapStateToProps(state, ownProps) {
    return {
    };
}
function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(loginAction, dispatch)
    };
}

Error.propTypes = {
    actions: PropTypes.object.isRequired,
    history: PropTypes.object.isRequired
};


export default connect(mapStateToProps, mapDispatchToProps)(Error);
