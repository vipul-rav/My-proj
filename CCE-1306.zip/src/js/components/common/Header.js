import React from 'react';
import PropTypes from 'prop-types';
import { Link, NavLink } from 'react-router-dom';
import { DropdownButton, MenuItem } from 'react-bootstrap';
import _ from 'lodash';
import headerLogo from '../../../assets/images/logo.png';


const Header = () => {
  return (
    <header className="header">
      <div>
      </div>
    </header>
  );
}


export default Header;
