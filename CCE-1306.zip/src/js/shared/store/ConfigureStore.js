import * as session from '../helpers/Persist';
import uuid from 'node-uuid';
import { createStore, applyMiddleware } from 'redux';
import rootReducer from '../../redux/reducers';
import reduxImmutableStateInvariant from 'redux-immutable-state-invariant';
import thunk from 'redux-thunk';


export default function configureStore(initialState) {
  createSession();
  return createStore(
    rootReducer,
    initialState,
    process.env.NODE_ENV === 'production' ?
      applyMiddleware(thunk)
      :
      applyMiddleware(thunk, reduxImmutableStateInvariant())
  );
}


function createSession() {
  let sessionId = session.getState('sessionId');

  if (!sessionId) {
    // Generate a new UUID.
    sessionId = uuid.v1();
    session.saveState('sessionId', sessionId);
  }
}