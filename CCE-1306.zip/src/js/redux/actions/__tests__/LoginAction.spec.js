import * as actions from '../LoginAction'
import * as types from '../../../shared/constant/ActionTypes';

describe('actions', () => {
    it('should create an action to add a todo', () => {
        const text = {
            "userId": "test",
            "bankId": "cb"
        }
        const expectedAction =   {"data": "agent", "type": "LOGIN_SUCCESS"}
        const success=jest.fn();
        console.log(actions.login('agent','agent'))
        expect(actions.loginsuccess('agent')).toEqual(expectedAction)
    })
})