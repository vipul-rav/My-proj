/**
	* @module CustomerReducer
	*/
import * as types from '../../shared/constant/ActionTypes';

const initialState = {
  customers: [],
  customerDetail: {},
  customerProduct: {},
  customerHistory: [],
  customerService: [],
  customerDetailFlag: false,
  customerProductFlag: false,
  customerHistoryFlag: false,
  customerServiceFlag: false

};

export default function CustomerReducer(state = initialState, action) {
  const newstate = Object.assign({}, [...state]);
  switch (action.type) {

    /**For displaying Customer List */
    case types.SEARCH_SUCCESS:
      newstate.customerDetail = state.customerDetail;
      newstate.customerProduct = state.customerProduct;
      newstate.customerHistory = state.customerHistory;
      newstate.customerService = state.customerService;
      newstate.customers = action.data;
      return newstate;

    /**For displaying Customer Information on Customer Summary */
    case types.CUSTOMERDETAIL_SUCCESS:
      newstate.customers = state.customers;
      newstate.customerProduct = state.customerProduct;
      newstate.customerHistory = state.customerHistory;
      newstate.customerService = state.customerService;
      newstate.customerDetail = action.data;
      newstate.customerDetailFlag = true;
      return newstate;

    /**For displaying Products on Customer Summary */
    case types.CUSTOMER_PRODUCT_SUCCESS:
      newstate.customers = state.customers;
      newstate.customerDetail = state.customerDetail;
      newstate.customerHistory = state.customerHistory;
      newstate.customerService = state.customerService;
      newstate.customerProduct = action.data;
      newstate.customerProductFlag = true;
      return newstate;

    /**For displaying Customer History on Customer Summary */
    case types.CUSTOMER_HISTORY_SUCCESS:
      newstate.customers = state.customers;
      newstate.customerDetail = state.customerDetail;
      newstate.customerProduct = state.customerProduct;
      newstate.customerService = state.customerService;
      newstate.customerHistory = action.data;
      newstate.customerHistoryFlag = true;
      return newstate;

    /**For displaying Services on Customer Summary */
    case types.CUSTOMERSERVICE_SUCCESS:
      newstate.customers = state.customers;
      newstate.customerDetail = state.customerDetail;
      newstate.customerProduct = state.customerProduct;
      newstate.customerHistory = state.customerHistory;
      newstate.customerService = action.data;
      newstate.customerServiceFlag = true;
      return newstate;
    /**For displaying Services on Customer Summary */
    case types.RESET_CUSTOMERS:
      return initialState;

    default:
      return state;

  }
}
