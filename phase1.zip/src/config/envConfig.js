
export default window.envConfig = {
	apiBaseUrl: 'https://my-test.cybservices.co.uk/bpiSITB',
	bankId: 'CB',
	callValidate3DTimelimit: 300000,
	disableAnalytics: false,
	trackingId: 'f3b083deb956a224b0bc2c7545973fbf9e53a7be',
};