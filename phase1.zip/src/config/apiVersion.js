export default window.apiVersion = {
    authServices:'0.8.0'
}
