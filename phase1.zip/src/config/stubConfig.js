export default window.stubConfig = 
{
   customerList:"customers.json"
};