import * as types from '../../shared/constant/actionTypes';
import loginApi from '../api/loginApi';


export function loginsuccess(data) {
  return {type: types.LOGIN_SUCCESS, data};
}

export function loginfailure(result) {
  return {type: types.LOGIN_FAILURE, data: result};
}

export function login(Id,password) {
  return function (dispatch) {
     console.log(Id,password)
    return loginApi.loginDetail(Id,password).then( result => {
       dispatch(loginsuccess(result)); 
    }).catch(error => {
      throw(error);
    });
  };
}

