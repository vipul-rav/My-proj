import * as types from '../../shared/constant/actionTypes';
import customerApi from '../api/customerApi';



export function searchSuccess(data){
  return {type:types.SEARCH_SUCCESS, data}
}

export function searchfailure(data){
  return {type:types.SEARCH_FAILURE, data}
}

export function loadCustomer(last_name,postcode) {
  return function(dispatch) {
    try{
    customerApi.getAllCustomers(last_name,postcode,dispatch,searchSuccess,searchfailure);
    //console.log(data);
      //dispatch(searchSuccess(data));
    } catch(error) {
      throw(error);
    }
  };
}
