import {combineReducers} from 'redux';
import courses from './courseReducer';
import user from './loginReducer';
import customers from './customerReducer';
import ajaxCallsInProgress from './ajaxStatusReducer';

const rootReducer = combineReducers({
  courses, 
  user,
  customers,
  ajaxCallsInProgress
});

export default rootReducer;
