import * as types from '../../shared/constant/actionTypes';

const initialState = {
  customers:[]
};

export default function customerReducer(state = initialState.customers, action) {
  const newstate = Object.assign({},state);
  switch (action.type) {
    case types.SEARCH_SUCCESS:
      return newstate.customers=action.data;
    default:
      return state;
  }
}
