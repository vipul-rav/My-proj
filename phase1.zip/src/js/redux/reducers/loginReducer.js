import * as types from '../../shared/constant/actionTypes';

const initialState={
  user:{
    isAuth:false
  }
}

const loginReducer = (state = initialState.user , action) => {
  const newState= Object.assign({}, state);
  switch (action.type) {
    case types.LOGIN_SUCCESS:
        newState.isAuth=action.data;
      return newState;
    case types.LOGIN_FAILURE:
     newState.isAuth=false;
     return Object.assign({},newState);
    default:
      return state;
  }
}

export default loginReducer;
