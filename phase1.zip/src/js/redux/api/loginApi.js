import delay from './delay';

class loginApi {
 static loginDetail(id,password) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (id =="piyush" && password == "syntel123$") {
          resolve(true);
        }
           else {
               resolve(true);
        }
      }, 
      delay);
    });
  }
}

export default loginApi;
