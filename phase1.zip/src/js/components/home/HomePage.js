import React,{Component} from 'react';
import { Link } from 'react-router';
import ButtonToolbar from 'react-bootstrap/lib/ButtonToolbar';
import Button from 'react-bootstrap/lib/Button';
import CustomerSearch from '../customer/CustomerSearch';
import Panel from 'react-bootstrap/lib/Panel';


export default class HomePage extends React.Component {
    constructor(props) {
    super(props);
    this.state = {
      data: '',
      isSearch:false
    }
    this.customerSearchOnClick = this.customerSearchOnClick.bind(this);
  }

  customerSearchOnClick() {
 
   this.setState({isSearch:true})
 }
  

  render() {
    return (
      
      <div>
        {!this.state.isSearch ?
        <div>
          <Panel>
        <strong><h3> Dashboard Page </h3></strong>
        <Button onClick={this.customerSearchOnClick} bsStyle="primary" >Customer Search</Button>
        <h4>{this.state.data}</h4>
        </Panel>
        </div>
        :
        <CustomerSearch/>
        }
      </div>
    );
  }
}


