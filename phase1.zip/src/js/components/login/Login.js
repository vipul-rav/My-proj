import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { Redirect } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import * as loginAction from '../../redux/actions/loginAction';

import Form from './Form';

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            error: ''
        }

        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleSubmit(id, password) {
        this.props.actions.login(id, password);
    }
    render() {
        return (
            <div>
                <Form redirectToDashboardPage={this.handleSubmit} errorMsg={this.state.error} />
            </div>
        )
    }
}

Login.propTypes = {
    actions: PropTypes.object.isRequired
}

const mapStateToProps = state => ({ user: state.user });


function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(loginAction, dispatch)
    };
}


export default connect(mapStateToProps, mapDispatchToProps)(Login);
