import React, {PropTypes} from 'react';
import {Link} from 'react-router';

const CustomerListRow = ({customer}) => {
  return (
    <tr>
      <td></td>
      <td>{customer.custid}</td>
      <td>{customer.name.first_name}</td>
      <td>{customer.address.address_prefix}</td>
      <td>{customer.postcode}</td>
    </tr>
  );
};

CustomerListRow.propTypes = {
  customer: PropTypes.object.isRequired
};

export default CustomerListRow;
