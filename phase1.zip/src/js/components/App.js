// This component handles the App template used on every page.
import React, { PropTypes } from 'react';
import Header from '../shared/common/Header';
import { connect } from 'react-redux';
import { Route, Redirect, withRouter } from 'react-router-dom';
import HomePage from './home/HomePage';
import Login from './login/Login';

class App extends React.Component {
  render() {
    return (
      <div className="container-fluid1">
        {this.props.user.isAuth
          ? <HomePage />
          : <Login />}
      </div>
    );
  }
}


App.propTypes = {
  user: PropTypes.object.isRequired
};

App.defaultProps = {
  showHeader: true
};

function mapStateToProps(state, ownProps) {
  return {
    user: state.user
  };
}

function mapDispatchToProps(dispatch) {
  return {

  };
}


export default connect(mapStateToProps, mapDispatchToProps)(App);
