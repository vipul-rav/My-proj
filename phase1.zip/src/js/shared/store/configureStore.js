import * as session from '../helpers/persist';
import uuid from 'node-uuid';
import { createStore, applyMiddleware } from 'redux';
import rootReducer from '../../redux/reducers';
import reduxImmutableStateInvariant from 'redux-immutable-state-invariant';
import thunk from 'redux-thunk';
import promise from "redux-promise-middleware";


// if (process.env.NODE_ENV === 'production') {
//   module.exports = require('./configureStore.prod');
// } else {
//   module.exports = require('./configureStore.dev');
// }


export default function configureStore(initialState) {
  createSession();
  return createStore(
    rootReducer,
    initialState,
    process.env.NODE_ENV === 'production' ?
      applyMiddleware(promise(),thunk)
      :
      applyMiddleware(promise(),thunk, reduxImmutableStateInvariant())
  );
}


function createSession() {
  let sessionId = session.getState('sessionId');

  if (!sessionId) {
    // Generate a new UUID.
    sessionId = uuid.v1();
    session.saveState('sessionId', sessionId);
  }
}