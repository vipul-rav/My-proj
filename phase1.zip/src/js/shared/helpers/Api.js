import { envBankConfig, general } from '../../../config/serviceConfig';
import BrowserUtils from '../utils/BrowserUtils';
import * as session from './persist';

const getClientContext = () => {
  // Default object
  const clientContext = {
    client: {},
    env: {
      // jscs: disable
      // jshint ignore:start
      platform_version: BrowserUtils.getBrowserVersion(),
      // jshint ignore:end
      // jscs: enable
      make: BrowserUtils.getPlatform(),

      locale: BrowserUtils.getUserLocale(),
      // For Payment Services BOW-36
      model: 'x86_64',
      geo_location: {
        longitude: -122.406417,
        latitude: 37.785834
      },
      device_lock_enabled: true,
      screen_size: {
        width: 1024,
        height: 768
      },
      device_name: 'iPad%20Simulator'
    }
  };

  // Appstore will contain the session id (generated uuid)
  // so that it doesn't change through-out
  clientContext.client['user_tracking_id'] = session.getState('sessionId');
  clientContext.client['app_title'] = general.documentTitle;
  clientContext.client['app_package_name'] = general.appPackageName;
  clientContext.client['app_version_code'] = general.version;
  clientContext.client['app_version_name'] = general.versionName;
  clientContext.env.platform = general.platform;

  return JSON.stringify(clientContext);
};



// export const post = async ({ url, body, success, dispatch }) => {
//   try {
//     const res = await fetch(url, {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify(body)
//     }).then((response) => response);

//     const data = await res.json();

//     if (!res.ok) {
//       dispatch({ type: types.SERVICE_ERROR, data });
//     } else {
//       dispatch({ type: success, data });
//     }

//   } catch (data) {
//     dispatch({ type: types.SERVICE_ERROR, data });
//   }
// };

function replaceBankId(url) {
  return url.replace('{bank-id}', envBankConfig.bankId)
}

/**
 * Make an API call.
 *
 * @param  {Object} callData 		All data about the call.
 * @param {Function} onSuccess 	Optional. No default. Callback when API call completes successfully.
 * @param {Function} onFail 	Optional. Default navigates user to error page. Callback when the API call fails.
 */
//export function makeAjaxCall(callData, onSuccess, onFail) {
export const makeAjaxCall = async (callData, onSuccess, onFail) => {

  const data = callData;

  if (!data.apiVersion) {
    console.warn('API call requires a version for endpoint', data.url);
  }

  const contentType = data.contentType === 'N' ? null : data.contentType || 'application/json';

  // // replace all placeholders in the url
  // _.each(_urlReplacements, (replaceWith, replaceString) => {
  // 	data.url = this.replaceUriString(data, replaceString, replaceWith);
  // });

  data.url = replaceBankId(data.url);

  const header =
    {
      'Accept': 'application/json',
      'x-bpi-version': data.apiVersion,
      'x-bpi-service-context': general.authentication.context,
      'Content-Type': 'application/json'
    };

  if (contentType !== null) {
    header['Content-Type'] = contentType;
  }



  // Auth token present?
  if (data.addAuthToken) {
    // const SessionStore = require('../stores/SessionStore');
    // const authToken = data.authToken || SessionStore.getToken()['access_token'];
    // if (authToken) {
    // 	request.set('Authorization', `Bearer ${authToken}`);
    // }
  } else if (data.authorizationHeader) {
    //	request.set('Authorization', data.authorizationHeader);
    header['Authorization'] = data.authorizationHeader
  }

  header['x-bpi-client-context'] = getClientContext();


  // Data to send?
  if (data) {
   
    try {
      const res = await fetch(data.url, {
        method: data.method,
        headers: header
      })

      const data1 = await res.json();

      if (res.status !== 200) {
        onFail(data1, 0);
      } else {
        onSuccess(data1, 1);
      }

    } catch (resp) {
       console.log(resp);
       onFail(resp, 0);
      
    }
  }

  /*
    request.end((err, res) => {
      // Now log that the request is finished.
      if (!data.doNotTrackCallProgress) {
        AppActions.trackApiCallComplete(data.url);
      }
      if (err) {
        let authHeader;
        let errorResponse;
        const errorStatus = err.status;
  
        if (err.response) {
          authHeader = err.response.headers[config.authenticateHeaderName];
          if (authHeader === undefined && errorStatus === 401 && data.url.search('oauth2/token') < 0) {
            authHeader = 'Bearer realm scope=40';
          }
          errorResponse = err.response.body || err.response.text;
        }
        // if (authHeader == undefined &&) {
        // }
        if (authHeader === 'Bearer realm error=tsandcs' && errorStatus === 401) {
          authHeader = undefined;
          errorResponse = err.response;
        }
  
        // Check for the auth header to see if the error requires step up authentication
        if (authHeader) {
          // If there is an authHeader, handle it and then exit.
  
          this.handleAuthHeader(authHeader, data, onSuccess, onFail);
          return;
        } else if (onFail) {
          if (errorResponse !== undefined && errorResponse.error !== undefined) {
            if (errorResponse.error.hasOwnProperty('id')) {
              errorResponse.error.quoteId = this.getQuoteId(errorResponse.error.id);
            } else {
              errorResponse.error.quoteId = ' ';
            }
          }
          onFail(errorResponse, errorStatus);
        } else {
          this.handleAjaxError(errorResponse, errorStatus);
        }
  
        return;
      }
  
      if (onSuccess) {
        onSuccess(res.body, res.status, res.text);
      }
    });*/
}

