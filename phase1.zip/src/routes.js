import React from 'react';
import { Route, IndexRoute } from 'react-router';
//import { Route } from 'react-router-dom';
import App from './js/components/App';
import HomePage from './js/components/home/HomePage';
import AboutPage from './js/components/about/AboutPage';
import CoursesPage from './js/components/course/CoursesPage';
import ManageCoursePage from './js/components/course/ManageCoursePage'; //eslint-disable-line import/no-named-as-default
import Header from './js/shared/common/Header';
import Login from './js/components/login/Login';

const Routes = () =>
  <div>
    <Header menuItem={menuItem} />
    <Route exact path="/home" component={HomePage} />
    <Route path="/courses" component={CoursesPage} />
    <Route path="/course" component={ManageCoursePage} />
    <Route path="/course/:id" component={ManageCoursePage} />
    <Route path="/login" component={Login} />
  </div>;

const menuItem = [
  {
    "title": "Course"
  }
];

export default Routes;




/*export default  (
      <Route path="/" component={App}>
    <IndexRoute component={HomePage} />
    <Route path="courses" component={CoursesPage} />
    <Route path="course" component={ManageCoursePage} />
    <Route path="course/:id" component={ManageCoursePage} />    
    <Route path="stubs/"  />
  </Route>
  
);*/
