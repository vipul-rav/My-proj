// This component handles the App template used on every page.
import React, { PropTypes } from 'react';
import Header from '../common/common/Header';
import { connect } from 'react-redux';

class App extends React.Component {
  render() {
    return (
      <div className="container-fluid1">
        {this.props.showHeader &&
          <Header
            loading={this.props.loading}
            />
        }

        {this.props.children}
      </div>
    );
  }
}

App.propTypes = {
  children: PropTypes.object.isRequired,
  loading: PropTypes.bool.isRequired
};

App.defaultProps = {
  showHeader: true
};

function mapStateToProps(state, ownProps) {
  return {
    loading: state.ajaxCallsInProgress > 0,
  };
}

export default connect(mapStateToProps)(App);
