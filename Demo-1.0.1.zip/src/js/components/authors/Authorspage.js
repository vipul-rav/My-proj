import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as authorActions from '../../actions/authorActions';
import AuthorList from './AuthorList';
import { browserHistory } from 'react-router';

class AuthorsPage extends React.Component {
  constructor(props, context) {
    super(props, context);
    // this.redirectToAddCoursePage = this.redirectToAddCoursePage.bind(this);
    this.changeBtn = this.changeBtn.bind(this);
    this.props.actions.loadAuthors();
    this.state = { count: false };

  }

  courseRow(course, index) {
    return <div key={index}>{course.title}</div>;
  }

  redirectToAddCoursePage() {
    browserHistory.push('/course');
  }

  changeBtn() {
    //this.setState({ count: !this.state.count });
     this.props.actions.ShowButtons(!this.props.authors.showBtn);
  }

  render() {
    const {authors} = this.props.authors;

    return (
      <div>
        <h1>Authors</h1>
        <input type="submit"
          value="Add Author"
          className="btn btn-primary"
          onClick={this.redirectToAddCoursePage} />

        <input type="submit"
          value="Show/Hide"
          className="btn btn-primary"
          onClick={this.changeBtn} />

        {this.props.authors.showBtn ?
          <input type="submit"
            value="test"
            className="btn btn-primary"
            /> : ''}

        <AuthorList authors={authors} />
      </div>
    );
  }
}

AuthorsPage.propTypes = {
  authors: PropTypes.array.isRequired,
  actions: PropTypes.object.isRequired,
  showBtn: PropTypes.bool
};

function mapStateToProps(state, ownProps) {
  return {
    authors: state.authors,
    showBtn:state.showBtn
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(authorActions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(AuthorsPage);
