import delay from './delay';
import accounts from '../stubs/AccountListConnection';
import request from 'superagent';
import currentAccount from '../stubs/AccountDetailsConnection-b80e95a0-6b60-45b2-8b0f-77f2355f3061';
import credit_card from '../stubs/AccountDetailsConnection-084c7a11-c91a-45ef-baea-2fd0e9556e16';
import payees from '../stubs/BeneficiaryListConnection';
import paymentSuccess from '../stubs/MakePaymentSuccess';

class PaymentApi {
  static getAccountsList() {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve(Object.assign([], accounts));
      }, delay);
    });
  }

  static getAccountDetails(type) {
    let accDet = {};
    if (type === 'current' || type === 'credit_card') {
      if (type !== 'current') {
        accDet = credit_card;
      }
      else {
        accDet = currentAccount;
      }
    }
    return new Promise((resolve, reject) => {
      resolve(Object.assign([], accDet));
    });
  }

  static getPayeeList() {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve(Object.assign([], payees));
      }, delay);
    });
  }



  static makeSOPayment(requestBody) {

    return new Promise((resolve, reject) => {
      setTimeout(() => {
        paymentSuccess.code=202;
        resolve(Object.assign([], paymentSuccess));
      }, delay);
    });
  }

  static makeDDPayment(requestBody) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
         paymentSuccess.code=202;
        resolve(Object.assign([], paymentSuccess));
      }, delay);
    });
  }

}
export default PaymentApi;
