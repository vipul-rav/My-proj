export default {
  authorState: {
    authors: [],
    showBtn: false
  },
  courses: [],
  ajaxCallsInProgress: 0,

};
