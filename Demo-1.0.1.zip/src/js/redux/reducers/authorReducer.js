import * as types from '../actions/actionTypes';
import initialState from './initialState';

export default function authorReducer(state, action) {
  let newState = Object.assign({}, state);
  switch (action.type) {
    case types.LOAD_AUTHORS_SUCCESS:
      newState.authors = action.authors;
      return newState;
    // return Object.assign({}, state.authors, {
    //   authors: action.authors
    // })
    // return state.authors = action.authors;
    case types.SHOW_BUTTONS:
      newState.showBtn = action.showBtn
      return newState;
    // return Object.assign({}, state.showBtn, {
    //   showBtn: action.showBtn,
    //   authors: state.authors
    // });

    default:
      return Object.assign({}, state, {
        authors: initialState.authorState.authors,
        showBtn: initialState.authorState.showBtn
      });
  }
}
