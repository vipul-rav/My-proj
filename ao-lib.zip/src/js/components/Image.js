import React, { Component } from 'react';
import PropTypes from 'prop-types';

let Image = ({ Id, name, imgClass, src, imgClick, imgText }) => {
    return (
        <img id={Id} className={imgClass} name={name} src={src} onClick={imgClick} />
    );
};


Image.defaultProps = {
    imgClass: '',
    name: 'img1',
    imgText: "Image"
};

Image.propTypes = {
    imgClass: PropTypes.object,
    imgText: PropTypes.string,
    name: PropTypes.string,
    src: PropTypes.string.isRequired,
    imgClick: PropTypes.func
};


export default Image;
