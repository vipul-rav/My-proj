import React from 'react';
import PropTypes from 'prop-types';

const AccountCard = ({ classNames, onClick, accountData, content }) => {
    return (
        <div className={`${classNames.account} ${classNames.accountmedium}`}>
            <h3 className={classNames.account__title}>
                <a className={classNames.account__link} href="" >
                    {content.CurrentAccount}
                </a>
            </h3>
            <dl className={classNames.account__defs}>
                <dt className={classNames.account__term}>
                    {content.Sortcode}
                </dt>
                <dd className={classNames.account__sortno}>
                    {accountData.Sortcode}
                </dd>
                <dt className={classNames.account__term}>
                    {content.AccountNumber}
                </dt>
                <dd className={classNames.account__accountno}>
                    {accountData.AccountNumber}
                </dd>
                <dt className={classNames.account__term}>
                    {content.Balance}
                </dt>
                <dd className={classNames.account__balance}>
                    &pound; {accountData.Balance}
                </dd>
                <dt className={classNames.account__term}>
                    {content.Remaining}
                </dt>
                <dd className={classNames.account__remaining}>
                    &pound; {accountData.available} {content.available}
                </dd>
            </dl>

        </div>
    );
};

AccountCard.propTypes = {
    onClick: PropTypes.func.isRequired,
    classNames: PropTypes.object.isRequired,
    accountData: PropTypes.object.isRequired,
    content: PropTypes.object.isRequired
};


export default AccountCard;