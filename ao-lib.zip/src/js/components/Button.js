import React from 'react';
import PropTypes from 'prop-types';

const Button = ({ className, text, btnClick }) => {
    return (
        <button className={className} onClick={btnClick}>{text} </button>
    );
};


Button.defaultProps = {
    className: "c-btn c-btn--primary",
    text: "Button"
};

Button.propTypes = {
  className: PropTypes.string,
  text: PropTypes.string,
  btnClick: PropTypes.func
};

export default Button;
