import React, { Component } from 'react';
import PropTypes from 'prop-types';

const FooterLink = ({ className, href, linkClick, content }) => {
    return (
        <p className={className}>
            <a href={href} onClick={linkClick} ><u>{content}</u></a>
        </p>
    );
};


FooterLink.defaultProps = {
    className: "footer-link",
    href: "#",
    content: "footer"
};

FooterLink.propTypes = {
  className: PropTypes.string,
  href: PropTypes.string,
  content: PropTypes.string
};


export default FooterLink;
