import React, { Component } from 'react';

const Range = ({ className, attributes, sliderChange }) => {
    return (
        <input type="range" className={className} onChange={sliderChange} min={attributes.min} max={attributes.max} defaultValue={attributes.value} step={attributes.step} />
    );
};

Range.defaultProps = {
    className: "Slider",
    attributes: {
        value: 0,
        step: 1,
        min: 0,
        max: 1
    }

};

export default Range;
