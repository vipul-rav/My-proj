import React from 'react';
import Button from './js/components/Button';
import Range from './js/components/Range';

class showControl extends React.Component {

    render() {
        return (
            <div>
                <div className="header">
                    <h2>  B UI Library</h2>
                </div>

                <h4 className="subtitle">
                    Default
                </h4>
                <div className="pattern-body">
                    <Button className='btn' />
                </div>

                <div className="pattern-body">
                    <button>
                        <span className="icon icon-icon__chevron-left">asdasdas</span>
                    </button>
                </div>
                <h4 className="pattern-subtitle subtitle">
                    Slider
                </h4>
                <div className="pattern-body">
                    <Range attributes={{ value: 8, step: 5, min: 0, max: 30 }}
                        classNames={{ sliderClass: "Slider", leftSectionClass: "slider-text slider-text-left", rightSectionClass: "slider-text slider-text-right" }}
                    />
                </div>
            </div>
        );
    }
}

export default showControl;