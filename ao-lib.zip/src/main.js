
import AccountCard from './js/components/AccountCard';

export default AccountCard;