
import 'babel-polyfill';
import promise from 'es6-promise';
import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
//import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
//import './assets/styles/common.css';
import './assets/styles/main.scss';
import Controls from './showControl';

const reactElement = document.getElementById('react');

document.body.classList.add("yb");
export const Root = () => <Controls />;

render(<Root />, reactElement);
