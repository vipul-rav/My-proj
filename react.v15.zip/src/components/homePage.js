
import React from 'react';
import { Router, Link } from 'react-router';

class Home extends React.Component {
	render() {
		return (
			<div className="jumbotron">
				<h1>React JS with ES 6</h1>
			</div>
		);
	}
}

export default Home;