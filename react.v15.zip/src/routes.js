
import React from 'react';
import { Route, IndexRoute,Router,browserHistory } from 'react-router';
import App from './components/app';
import Home from './components/homePage';


var routes = (
  <Router>
      <Route path = "/" component = {App}>
         <IndexRoute component = {Home} />
         <Route path = "home" component = {Home} />
      </Route>
   </Router>
);

export default routes;