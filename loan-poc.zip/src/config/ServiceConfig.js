import envConfig from './EnvConfig';
import apiVersion from './ApiVersion';
import stub from './StubConfig';

export const isStub = false;

export const envBankConfig = envConfig;

export const apiVersions = apiVersion;

export const stubConfig=stub;

export const ApiBaseUrl = () => {
	let url = "http://localhost:" + window.location.port;

	//const isStub = false;
	if (isStub) {
		url = url + "/stubs/";
	}
	else
		url = global.envConfig.apiBaseUrl;

	return url;
};


export const general = {
	version: '1.0.0',
	versionName: 'Milestone_1',
	appPackageName: 'BWEB',
	platform: 'B Web',
	compatibleBrowsers: [
		{ browser: 'chrome', version: 39 },
		{ browser: 'safari', version: 8 },
		{ browser: 'msie', version: 11 },
		{ browser: 'msedge', version: 12 },
		{ browser: 'firefox', version: 33 },
		{ browser: 'opera', version: 38 }
	],
	authentication: {
		context: 'USER'
	},
	documentTitle:'B Web'
};



