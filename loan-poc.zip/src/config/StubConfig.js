export default window.stubConfig =
    {
        login: "login.json",
        applyLoan:"Loan-#pref.json",
        EligibleLoanAmount:'EligibleLoanAmount.json',
        customerList: "customers.json",
        customerDetailsStub: "customerDetails-",
        customerProductStub: "products-",
        customerHistoryStub: "CustomerHistoryDetails-",
        customerServiceStub: "CustomerServiceDetail-"
    };