
export default window.envConfig = {
	apiBaseUrl: 'http://localhost:8080/SpringRestExample/rest/product/',
	bankId: 'CB',
	callValidate3DTimelimit: 300000,
	disableAnalytics: false,
	trackingId: '33e3e820-4151-11e7-b81a-e394c00d05ee'
};