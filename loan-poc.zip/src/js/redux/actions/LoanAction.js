
/**
	* @module loanAction
	*/

import * as types from '../../shared/constant/ActionTypes';
import LoanApi from '../api/LoanApi';
import * as StringConstant from '../../shared/constant/StringConstant';

/**On successful loan*/
function eligibleSuccess(data) {
    return { type: types.ELIGIBLE_SUCCESS, data };
}

function eligibleFailure(result) {
    return { type: types.ELIGIBLE_FAILURE, data: result };
}


function loanForSuccess(data) {
    return { type: types.LOANFOR_SUCCESS, data };
}

function loanForFailure(result) {
    return { type: types.LOANFOR_FAILURE, data: result };
}

function borrowLoanSuccess(data) {
    return { type: types.BORROW_SUCCESS, data };
}

function borrowLoanFailure(result) {
    return { type: types.BORROW_FAILURE, data: result };
}

export function getLoanContent(brand, page) {
    return function (dispatch) {
        try {
            if (page === StringConstant.PREF_1)
                LoanApi.getLoanContent(brand, page, dispatch, eligibleSuccess, eligibleFailure);
            else if (page === StringConstant.PREF_2)
                LoanApi.getLoanContent(brand, page, dispatch, loanForSuccess, loanForFailure);
            else if (page === StringConstant.PREF_3) {
                LoanApi.getLoanContent(brand, page, dispatch, borrowLoanSuccess, borrowLoanFailure);
            }
        } catch (error) {
            throw (error);
        }
    };
}



function EligibleLoanDataSuccess(data) {
    return { type: types.ELIGIBLE_DATA_SUCCESS, data };
}

function EligibleLoanDataFailure(result) {
    return { type: types.ELIGIBLE_DATA_FAILURE, data: result };
}


export function getEligibleLoanData(brand, page) {
    return function (dispatch) {
        try {
            LoanApi.getLoanData(brand, page, dispatch, EligibleLoanDataSuccess, EligibleLoanDataFailure);
        } catch (error) {
            throw (error);
        }
    };
}


function BorrowLoanDataSuccess(data) {
    return { type: types.BORROW_DATA_SUCCESS, data };
}

function BorrowLoanDataFailure(result) {
    return { type: types.BORROW_DATA_FAILURE, data: result };
}

export function getBorrowLoanData(brand, page) {
    return function (dispatch) {
        try {
            LoanApi.getBorrowLoanData(brand, page, dispatch, BorrowLoanDataSuccess, BorrowLoanDataFailure);
        } catch (error) {
            throw (error);
        }
    };
}



function SliderAmountSuccess(data) {
    return { type: types.SLIDER_DATA_SUCCESS, data };
}

function SliderAmountFailure(result) {
    return { type: types.SLIDER_DATA_FAILURE, data: result };
}

export function getSliderAmount(brand, page) {
    return function (dispatch) {
        try {
            LoanApi.getSliderAmount(brand, page, dispatch, SliderAmountSuccess, SliderAmountFailure);
        } catch (error) {
            throw (error);
        }
    };
}




