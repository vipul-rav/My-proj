/**
	* @module CustomerAction
	*/

import * as types from '../../shared/constant/ActionTypes';
import customerApi from '../Api/CustomerApi';


/**To Display Customer List on Customer Search*/
export function searchSuccess(data) {
  return { type: types.SEARCH_SUCCESS, data };
}
export function searchfailure(data) {
  return { type: types.SEARCH_FAILURE, data };
}
export function loadCustomer(last_name, postcode, initials, bankname) {
  return function (dispatch) {
    try {
      customerApi.getAllCustomers(last_name, postcode, initials, bankname, dispatch, searchSuccess, searchfailure);
    } catch (error) {
      throw (error);
    }
  };
}

/**To Display Customer Information on Customer Summary */
export function customerDetailsSuccess(data) {
  return { type: types.CUSTOMERDETAIL_SUCCESS, data };
}

export function customerDetailsFailure(data) {
  return { type: types.CUSTOMERDETAIL_FAILURE, data };
}

export function customerDetails(id) {
  return function (dispatch) {
    try {
      customerApi.getCustomerDetails(id, dispatch, customerDetailsSuccess, customerDetailsFailure);
    } catch (error) {
      throw (error);
    }
  };
}

/**To Display Products on Customer Summary*/
export function customerProductSuccess(data) {
  return { type: types.CUSTOMER_PRODUCT_SUCCESS, data };
}

export function customerProductFailure(data) {
  return { type: types.CUSTOMER_PRODUCT_FAILURE, data };
}

export function customerProduct(id) {
  return function (dispatch) {
    try {
      customerApi.getCustomerProduct(id, dispatch, customerProductSuccess, customerProductFailure);
    } catch (error) {
      throw (error);
    }
  };
}


/**To Display History on Customer Summary*/
export function customerHistorySuccess(data) {
  return { type: types.CUSTOMER_HISTORY_SUCCESS, data };
}

export function customerHistoryFailure(data) {
  return { type: types.CUSTOMER_HISTORY_FAILURE, data };
}

export function customerHistory(id) {
  return function (dispatch) {
    try {
      customerApi.getCustomerHistory(id, dispatch, customerHistorySuccess, customerHistoryFailure);
    } catch (error) {
      throw (error);
    }
  };
}



export function customerServiceSuccess(data) {
  return { type: types.CUSTOMERSERVICE_SUCCESS, data };
}

export function customerServiceFailure(data) {
  return { type: types.CUSTOMERSERVICE_FAILURE, data };
}

/**To Display Services on Customer Summary*/
export function customerService(id) {
  return function (dispatch) {
    try {
      customerApi.getCustomerService(id, dispatch, customerServiceSuccess, customerServiceFailure);
    } catch (error) {
      throw (error);
    }
  };
}


/**To reset the customer list*/
export function resetCustomers() {
  return function (dispatch) {
    try {
      return dispatch({ type: types.RESET_CUSTOMERS });
    } catch (error) {
      throw (error);
    }
  };
}