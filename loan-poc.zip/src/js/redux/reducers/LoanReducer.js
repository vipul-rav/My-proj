/**
	* @module LoanReducer
	*/

import * as types from '../../shared/constant/ActionTypes';

const initialState = {
    appHeader_text: '',
    eligibleLoan: undefined,
    loanFor: undefined,
    borrowLoan: undefined,
    loanData: {
        eligibleAmount: {},
        borrowAmount: {},
        sliderAmount: {}
    }
};


const LoanReducer = (state = initialState, action) => {
    const newState = Object.assign({}, state);
    switch (action.type) {
        case types.ELIGIBLE_SUCCESS:
            newState.appHeader_text = action.data[0].app_headear_text;
            newState.eligibleLoan = action.data[0];
            return newState;
        case types.ELIGIBLE_FAILURE:
            return Object.assign({}, newState);
        case types.LOANFOR_SUCCESS:
            newState.appHeader_text = action.data[0].app_headear_text;
            newState.loanFor = action.data[0];
            return newState;
        case types.LOANFOR_FAILURE:
            return Object.assign({}, newState);
        case types.BORROW_SUCCESS:
            newState.appHeader_text = action.data[0].app_headear_text;
            newState.borrowLoan = action.data[0];
            return newState;
        case types.BORROW_FAILURE:
            return Object.assign({}, newState);
        case types.ELIGIBLE_DATA_SUCCESS:
            newState.loanData = Object.assign({}, state.loanData);
            newState.loanData.eligibleAmount = Object.assign({}, action.data);
            return newState;
        case types.ELIGIBLE_DATA_FAILURE:
            return Object.assign({}, newState);
        case types.BORROW_DATA_SUCCESS:
           
            newState.loanData = Object.assign({}, state.loanData);
            newState.loanData.borrowAmount = Object.assign({}, action.data);
            
            return newState;
        case types.BORROW_DATA_FAILURE:
            return Object.assign({}, newState);
        case types.SLIDER_DATA_SUCCESS:
            
            newState.loanData = Object.assign({}, state.loanData);
            newState.loanData.sliderAmount = Object.assign({}, action.data);
           
            return newState;
        case types.SLIDER_DATA_FAILURE:
            return Object.assign({}, newState);
        default:
            return state;
    }
};

export default LoanReducer;