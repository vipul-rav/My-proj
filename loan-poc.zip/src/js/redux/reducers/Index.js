import { combineReducers } from 'redux';

import user, * as login from './LoginReducer';
import customers from './CustomerReducer';
import loan from './LoanReducer';



const rootReducer = combineReducers({
  user,
  customers,
  loan
});


export const getAuthToken = () => {
  return login.getAuthToken();
};

export default rootReducer;
