import reducer from '../CustomerReducer';
import * as types from '../../../shared/constant/ActionTypes';
import expect from 'expect';

describe('Customer reducer', () => {
    it('should return the initial state', () => {
        expect(
            reducer(undefined, {})
        ).toEqual(
            {
                customerDetail: {},
                customerDetailFlag: false,
                customerHistory: [],
                customerHistoryFlag: false,
                customerProduct: {},
                customerProductFlag: false,
                customerService: [],
                customerServiceFlag: false,
                customers: []
            }
            );
    });

    it('should handle Search customer', () => {
        expect(
            reducer({}, {
                type: types.SEARCH_SUCCESS,
                data: [
                    {
                        "id": "83828732-236a-b37e-96bd-723b12bea564",
                        "customer_number": "1037912302",
                        "name": "Angel Boyce",
                        "address": "System Delivery, GBIT, Cylde bank",
                        "postcode": "C"
                    },
                    {
                        "id": "83828732-236a-b37e-96bd-723b12bea565",
                        "customer_number": "1037912312",
                        "name": "Smith Bob",
                        "address": "System Delivery, GBIT, Cylde bank",
                        "postcode": "C"
                    }]
            })
        ).toEqual(
            {
                customers: [
                    {
                        "id": "83828732-236a-b37e-96bd-723b12bea564",
                        "customer_number": "1037912302",
                        "name": "Angel Boyce",
                        "address": "System Delivery, GBIT, Cylde bank",
                        "postcode": "C"
                    },
                    {
                        "id": "83828732-236a-b37e-96bd-723b12bea565",
                        "customer_number": "1037912312",
                        "name": "Smith Bob",
                        "address": "System Delivery, GBIT, Cylde bank",
                        "postcode": "C"
                    }]
            }
            );
    });

    it('should handle customer detail', () => {
        expect(
            reducer({}, {
                type: types.CUSTOMERDETAIL_SUCCESS,
                data: {
                    "id": "83828732-236a-b37e-96bd-723b12bea564",
                    "customer_number": "",
                    "display_name": "Miss Angel Boyce",
                    "personal_details": {
                        "name": {
                            "title": "Miss",
                            "first_name": "Angle",
                            "middle_name": "",
                            "last_name": "Boyce"
                        }
                    }
                }
            })
        ).toEqual(
            {
                customerDetail: {
                    "id": "83828732-236a-b37e-96bd-723b12bea564",
                    "customer_number": "",
                    "display_name": "Miss Angel Boyce",
                    "personal_details": {
                        "name": {
                            "title": "Miss",
                            "first_name": "Angle",
                            "middle_name": "",
                            "last_name": "Boyce"
                        }
                    }

                },
                customerDetailFlag: true
            }
            );
    });

    it('should handle customer product', () => {
        expect(
            reducer({}, {
                type: types.CUSTOMER_PRODUCT_SUCCESS,
                data: {
                    "accounts": [{
                        "id": "2f9dcda3-01a7-4c4c-8d23-feda773ce123",
                        "number": "820101-12345678",
                        "type": "current",
                        "product": {
                            "code": "310",
                            "name": "CURRENT ACCOUNT",
                            "description": "CURRENT ACCOUNT PLUS"
                        },
                        "metadata": {
                            "display_name": "Rainy Day Account",
                            "visibility": true,
                            "display_order": 1

                        },
                        "bank_id": "CB"
                    }]
                }
            })
        ).toEqual(
            {
                customerProduct: {
                    "accounts": [{
                        "id": "2f9dcda3-01a7-4c4c-8d23-feda773ce123",
                        "number": "820101-12345678",
                        "type": "current",
                        "product": {
                            "code": "310",
                            "name": "CURRENT ACCOUNT",
                            "description": "CURRENT ACCOUNT PLUS"
                        },
                        "metadata": {
                            "display_name": "Rainy Day Account",
                            "visibility": true,
                            "display_order": 1

                        },
                        "bank_id": "CB"
                    }]
                },
                customerProductFlag: true
            }
            );
    });

    it('should handle customer history', () => {
        expect(
            reducer({}, {
                type: types.CUSTOMER_HISTORY_SUCCESS,
                data: [{
                    "date": "05/05/2017 14:14:26",
                    "location": "TB",
                    "rating": "",
                    "description": "Log,Customer Searched "
                }]
            })
        ).toEqual(
            {
                customerHistory: [{
                    "date": "05/05/2017 14:14:26",
                    "location": "TB",
                    "rating": "",
                    "description": "Log,Customer Searched "
                }],
                customerHistoryFlag: true
            }

            );
    });


    it('should handle customer services', () => {
        expect(
            reducer({}, {
                type: types.CUSTOMERSERVICE_SUCCESS,
                data: [{
                    "service_name": "IVR",
                    "active": "Active",
                    "inactive_reason": "",
                    "date": "15/05/2014"
                }]
            })
        ).toEqual(
            {

                customerService: [{
                    "service_name": "IVR",
                    "active": "Active",
                    "inactive_reason": "",
                    "date": "15/05/2014"
                }],
                customerServiceFlag:true

            }
            );
    });


    it('should handle reset customer', () => {
        expect(
            reducer({}, {
                type: types.RESET_CUSTOMERS
            })
        ).toEqual(
            {
                customerDetail: {},
                customerDetailFlag: false,
                customerHistory: [],
                customerHistoryFlag: false,
                customerProduct: {},
                customerProductFlag: false,
                customerService: [],
                customerServiceFlag: false,
                customers: []
            }
            );
    });


});