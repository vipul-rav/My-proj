/**
	* @module LoginReducer
	*/

import * as types from '../../shared/constant/ActionTypes';

let authToken = {};

const initialState = {
  user: {
    isAuth: false,
    authToken: authToken,
    userIdentity: {}
  }
};

export const getAuthToken = () => {
  return authToken;
};

const LoginReducer = (state = initialState.user, action) => {
  const newState = Object.assign({}, state);
  switch (action.type) {
    case types.LOGIN_SUCCESS:
      newState.isAuth = true;
      newState.authToken = { "userId": action.data.userId };
      authToken = { "userId": action.data.userId };
      return newState;
    case types.LOGIN_FAILURE:
      newState.isAuth = false;
      return Object.assign({}, newState);
    case types.RESET_AUTH:
      return Object.assign({}, initialState);
    default:
      return state;
  }
};

export default LoginReducer;