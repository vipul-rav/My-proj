/**
	* @module LoginApi
	*/

import { makeAjaxCall } from '../../shared/helpers';
import { ApiBaseUrl, isStub, stubConfig, apiVersions } from '../../../config/ServiceConfig';
import _ from 'lodash';
import * as StringConstant from '../../shared/constant/StringConstant';
const _getLoanContent = '/banks/{bank-id}/accounts/default';
const eligibleLoanAmount = 'elligibleAmount';
const borrowLoanAmount = 'borrow/amount';
const sliderAmount = 'slider/amount';


class LoanApi {
    static getLoanContent(brand, page, dispatch, success, failure) {

        let url = ApiBaseUrl() + page;
        if (isStub)
            url = ApiBaseUrl() + stubConfig.applyLoan.replace("#pref", page);

        makeAjaxCall({
            apiVersion: apiVersions.authServices,
            method: StringConstant.GET,
            url,
            addAuthToken: false
        }, (body, status) => {
            dispatch(success(body));
        }, (error, status) => {
            dispatch(failure([]));
        });

    }

    static getLoanData(brand, page, dispatch, success, failure) {

        let url = ApiBaseUrl() + eligibleLoanAmount;
        if (isStub)
            url = ApiBaseUrl() + stubConfig.EligibleLoanAmount;

        makeAjaxCall({
            apiVersion: apiVersions.authServices,
            method: StringConstant.GET,
            url,
            addAuthToken: false
        }, (body, status) => {
            dispatch(success(body));
        }, (error, status) => {
            dispatch(failure([]));
        });

    }


    static getBorrowLoanData(brand, page, dispatch, success, failure) {

        let url = ApiBaseUrl() + borrowLoanAmount;
        if (isStub)
            url = ApiBaseUrl() + stubConfig.EligibleLoanAmount;

        makeAjaxCall({
            apiVersion: apiVersions.authServices,
            method: StringConstant.GET,
            url,
            addAuthToken: false
        }, (body, status) => {
            dispatch(success(body));
        }, (error, status) => {
            dispatch(failure([]));
        });

    }

    static getSliderAmount(brand, page, dispatch, success, failure) {

        let url = ApiBaseUrl() + sliderAmount;
        if (isStub)
            url = ApiBaseUrl() + stubConfig.EligibleLoanAmount;

        makeAjaxCall({
            apiVersion: apiVersions.authServices,
            method: StringConstant.GET,
            url,
            addAuthToken: false
        }, (body, status) => {
            dispatch(success(body));
        }, (error, status) => {
            dispatch(failure([]));
        });

    }



}


export default LoanApi;
