/**
	* @module LoginApi
	*/

import { makeAjaxCall } from '../../shared/helpers';
import { ApiBaseUrl, isStub, stubConfig, apiVersions } from '../../../config/ServiceConfig';
import _ from 'lodash';
const GenericMapperUtils = require('../../shared/utils/GenericMapperUtils');
import JSEncrypt from '../../../static/jsencrypt.min.js';
import * as StringConstant from '../../shared/constant/StringConstant';
const _getLogin = '/banks/{bank-id}/accounts/default';


class LoginApi {
  static loginDetail(id, password, dispatch, success, failure) {

    let url = ApiBaseUrl() + _getLogin;
    if (isStub)
      url = ApiBaseUrl() + stubConfig.login;

    const body = {
      "userId": id,
      "password": password
    };
    
    makeAjaxCall({
      apiVersion: apiVersions.authServices,
      method: isStub ? StringConstant.GET : StringConstant.POST,
      url,
      addAuthToken: false,
      body: body

    }, (body, status) => {
      dispatch(success(body));
    }, (error, status) => {
      dispatch(failure([]));
    });



  }
}





//   static getSecretAnswer(body) {

//     const pass = ['P', 'a', 's', 's', 'w', 'o', 'r', 'd', '@', '1', '2', '3'];

//     const challanges = body.auth_schemes[0].challenges.partial_password.positions;
//     const answer = [3];

//     answer[0] = this.encryptAnswer(body, pass[parseInt(challanges[0]) - 1]);
//     answer[1] = this.encryptAnswer(body, pass[parseInt(challanges[1]) - 1]);
//     answer[2] = this.encryptAnswer(body, pass[parseInt(challanges[2]) - 1]);

//     return answer;
//   }

//   static encryptAnswer(data, value) {
//     const sessionId = data['auth_session_id'];
//     const publicKey = data['public_key'];
//     return this.encrypt(publicKey, `${sessionId}:${value}`);
//   }

//   static encrypt(publicKey, value) {
//     if (!_.isString(value) && !_.isNumber(value)) {
//       return undefined;
//     }
//     const encrypt = new JSEncrypt();
//     encrypt.setPublicKey(publicKey);
//     return encrypt.encrypt(value);
//   }


//   static callTokenAPI(data) {

//     const body = "grant_type=client_credentials&scope=30";

//     let authorizationHeader = JSON.stringify(
//       this.buildChallengeResponse(data.userIdentity, data.challengeResponse, data.authData)
//     );
//     makeAjaxCall({
//       apiVersion: '0.8.0',
//       method: 'POST',
//       url: "https://my-dev.cybservices.co.uk/bpiInt3/banks/CB/auth/provider/oauth2/token",
//       addAuthToken: false,
//       authorizationHeader: `Basic ${btoa(authorizationHeader)}`,
//       contentType: 'application/x-www-form-urlencoded',
//       body: body
//     },
//       (body1, status) => {

//       }, (error, status) => {
//       });






//   }


//   static buildChallengeResponse(userIdentity, challengeResponse, authData) {
//     const authSchema = { userIdentity: { userInfo: { dateOfBirth: 'dob', postcode: 'post_code' } } };

//     const response = {};
//     response.auth_session_id = challengeResponse.auth_session_id;
//     response.auth_schemes = [];

//     if (!challengeResponse.auth_schemes) {
//       return response;
//     }

//     const userIdentityValue = UserIdentityBuilder.build(userIdentity);

//     _.each(challengeResponse.auth_schemes, scheme => {
//       let challengeResponses = {};
//       const nextChallengeResponse = _.partial(_.assign, {}, challengeResponses);

//       if (scheme.challenges.partial_password) {
//         const partialPassword = {};
//         _.each(scheme.challenges.partial_password.positions, (pos, index) => {
//           partialPassword[pos] = authData['partial-password'][index];
//         });

//         challengeResponses = nextChallengeResponse({ partialPassword });
//       }

//       if (scheme.challenges.security_questions) {
//         const securityQuestions = {
//           answers: _.clone(authData['security-questions'])
//         };
//         challengeResponses = nextChallengeResponse({ securityQuestions });
//       }

//       if (scheme.challenges.acn) {
//         const acn = _.pick(authData.acn, ['access_code', 'sort_code', 'account_number']);
//         challengeResponses = nextChallengeResponse({ acn });
//       }

//       if (scheme.challenges.debit_card) {
//         const debitCard = _.pick(authData.debit_card, ['pan', 'sort_code', 'account_number']);
//         challengeResponses = nextChallengeResponse({ debitCard });
//       }

//       if (scheme.challenges.otp) {
//         const otp = _.clone(authData.otp.otp);
//         challengeResponses = nextChallengeResponse({ otp });
//       }

//       const newData = _.assign({}, userIdentityValue, {
//         id: scheme.id,
//         challengeResponses
//       });

//       const newSchemeData = GenericMapperUtils.mapObject(newData, authSchema);

//       response.auth_schemes.push(newSchemeData);
//     });

//     return response;
//   }


// }



// const UserIdentityBuilder = {
// 	/**
// 	 * Responsible for building the entire userIdentity object.
// 	 *
// 	 * @param {string|UUID|object} source source to be mapped
// 	 *
// 	 * @return {Object} userIdentity object
// 	 *
// 	 * @example // username
// 	 *
// 	 * // 'username' => { userIdentity: { userName: 'username' } }
// 	 *
// 	 * // Unfortuently, the API doesn't comply to the SD, so we need to mangle our
// 	 * data and send userName as userId currently
// 	 *
// 	 * 'username' => { userIdentity: { userId: 'username' } }
// 	 *
// 	 * // UUID
// 	 *
// 	 * '8af6473a-42e0-40c3-ab66-7d156fabea93' =>
// 	  * { userIdentity: { userId: '8af6473a-42e0-40c3-ab66-7d156fabea93' } }
// 	 *
// 	 * // User Info
// 	 *
// 	 * { firstName: 'firstName', ...} =>
// 	 * { userIdentity: { userInfo: { firstName: 'firstName', ... } } }
// 	 *
// 	 */
//   build: source => _.flow(UserIdentityBuilder.buildBody, UserIdentityBuilder.userIdentity)(source),

// 	/**
// 	 * Responsble for building the body of the userIdentity object.  Runs conditions
// 	 * to assert what we are dealing with, and delegates to the appropriate mapper method
// 	 *
// 	 * @param {String|UUID|Object} source source to be mapped
// 	 *
// 	 * @return {Object} mapped object matches the source
// 	 *
// 	 */
//   buildBody: source => {
//     if (UserIdentityBuilder.isUUID(source)) {
//       return UserIdentityBuilder.fromUserId(source);
//     }

//     if (_.isString(source)) {
//       return UserIdentityBuilder.fromUsername(source);
//     }

//     if (_.isPlainObject(source)) {
//       return UserIdentityBuilder.fromUserInfo(source);
//     }

//     throw new Error(`source invalid source: ${source}`);
//   },

// 	/**
// 	 * Builds a userName object to later be sent to the UI.  We are using
// 	 * the paramater name to ensure propery name, so we can send it correctly
// 	 * to the API.  It will later be translated to user_name based on camelcase -> snakecasing
// 	 * transformer used within the mapper.
// 	 *
// 	 * @param {String} userName username to be user to create the username object
// 	 *
// 	 * @return {Object} new userName object
// 	 *
// 	 * @example // 'username' => {userName: 'username'}
// 	 *
// 	 * 'username' => {userId: 'username'}
// 	 *
// 	 * @ticket DYB-19034
// 	 */
//   fromUsername: userName => {
//     if (!_.isString(userName)) {
//       throw new Error('userName must be a string');
//     }

//     return { userId: userName };
//   },

// 	/**
// 	 * Builds the userIdentity object.
// 	 *
// 	 * @param {Object} userIdentity userIdentity object to be used to contruct the userIdentity
// 	 * object required by the API
// 	 *
// 	 * @return {Object} Correctly constructed userIdentity
// 	 *
// 	 * @example userIdenty => {userIdentity: userIdentity}
// 	 *
// 	 */
//   userIdentity: userIdentity => ({ userIdentity }),

// 	/**
// 	 * Builds the userId object.
// 	 *
// 	 * @param {Object} userId userIdentity object to be used to contruct the userId
// 	 * object required by the API
// 	 *
// 	 * @return {Object} Correctly constructed userId
// 	 *
// 	 * @example '8af6473a-42e0-40c3-ab66-7d156fabea93' =>
// 	 * {userId: '8af6473a-42e0-40c3-ab66-7d156fabea93'}
// 	 *
// 	 */
//   fromUserId: userId => {
//     if (!UserIdentityBuilder.isUUID(userId)) {
//       throw new Error(`${JSON.stringify(userId)} is not a UUID`);
//     }
//     return ({ userId });
//   },

// 	/**
// 	 * Builds the UserInfo object.
// 	 *
// 	 * @param {Object} userId userIdentity object to be used to contruct the UserInfo
// 	 * object required by the API
// 	 *
// 	 * @return {Object} Correctly constructed UserInfo
// 	 *
// 	 * @example { firstName: 'firstName', ...} => { userInfo: { firstName: 'firstName', ... } }
// 	 *
// 	 */
//   fromUserInfo: userInfo => ({ userInfo }),

// 	/**
// 	 * Helper method for matching UUIDs
// 	 *
// 	 * @param {String} source userIdentity object to be used to contruct the fromUserInfo
// 	 * object required by the API
// 	 *
// 	 * @return {Boolean} True if source matches UUID regex, false otherwise
// 	 */
//   isUUID: source => /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/.test(source)
// };

export default LoginApi;
