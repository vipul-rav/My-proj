
export const POST = "POST";
export const GET = "GET";
export const PUT = "PUT";
export const DELETE = "DELETE";
export const PREF_1 = "pre-1";
export const PREF_2 = "pre-2";
export const PREF_3 = "pre-3";


