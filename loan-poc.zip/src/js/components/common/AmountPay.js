import React, { Component } from 'react';

const AmountPay = ({ classNames, headerText, value }) => {
    return (
        <section className={classNames.mainClass}>
            <p className={classNames.headerClass}>
                {headerText}
            </p>
            <p className={classNames.valueClass}><b>&pound; {value}</b></p>
        </section>
    );
};


AmountPay.defaultProps = {
    classNames: {
        mainClass: "mask-left",
        headerClass: "mask-upline",
        valueClass: "mask-downline"
    },
    content: "Monthly repayments",
    value: 0
};

export default AmountPay;















{/*<div className={classNames.mainClass}>
            <div className={classNames.headerClass}>{headerText} </div>
            <div className={classNames.valueClass}>  {value} </div>
        </div>*/}