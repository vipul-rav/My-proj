import React, { Component } from 'react';
import mainImg from '../../../assets/images/Main Icon.png';

const TextHeader = ({ topImg, classNames, content }) => {
    return (
        <div>
            <div className={classNames.imgClass}><img src={topImg} /></div>
            <div className={classNames.txtClass} dangerouslySetInnerHTML={{ __html: content }} />
        </div>);
};

TextHeader.defaultProps = {
    topImg: mainImg,
    classNames: {
        imgClass: "Marketing-promo",
        txtClass: "You-are-eligible-for"
    }
};

export default TextHeader;

