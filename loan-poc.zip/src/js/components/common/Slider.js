import React, { Component } from 'react';
import Minus from '../../../assets/images/Minus.png';
import Plus from '../../../assets/images/Plus.png';

const Slider = ({ Minus, Plus, className, attributes, minValue, maxValue, sliderChange, minusClick, plusClick }) => {
    return (
        <div>
            <img src={Minus} onClick={minusClick} />
            <input type="range" className={className} onChange={sliderChange} min={attributes.min} max={attributes.max} value={attributes.value} step={attributes.step} />
            <img src={Plus} onClick={plusClick} />
            <section className="slider-text slider-text-left">{attributes.min}</section>
            <section className="slider-text slider-text-right">{attributes.max}</section>
        </div>
    );
};

Slider.defaultProps = {
    Minus: Minus,
    Plus: Plus,
    className: "Slider",
    attributes: {
        value: 0,
        step: 1,
        min: 0,
        max: 1
    }

};

export default Slider;
