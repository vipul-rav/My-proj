import React, { Component } from 'react';

const MarketPromo = ({ classNames, content }) => {

    return (<div>
        <div className={classNames.HeadClass}>
            {content.header}
        </div>
        <div className={classNames.BodyClass}>
            {content.body}
        </div>
    </div>);
};


MarketPromo.defaultProps = {
    classNames: {
        HeadClass: "Marketing-Promo-mess",
        BodyClass: "Lorem-ipsum-dolor-si"
    },
    content: {
        header: "Marketing Promo message",
        body: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sollicitudin, quam sed malesuada rhoncus, risus massa scelerisque dolor, vitae consequat nunc quam nec mauris. In hac habitasse platea dictumst. Ut quis justo diam. Mauris dapibus ornare gravida."
    }
};

export default MarketPromo;
