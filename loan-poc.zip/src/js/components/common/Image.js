import React, { Component } from 'react';

const Image = ({ classNames, src, imgClick, imgText }) => {
    return (
        <span>
            <img className={classNames.imgClass} src={src} onClick={imgClick} />
            {/*<p className={classNames.textClass}>
                {imgText}
            </p>*/}
        </span>
    );
};


Image.defaultProps = {
    classNames: {
        imgClass: "Oval",
        textClass: "imgText"
    },
    imgText: "Image"
};

export default Image;
