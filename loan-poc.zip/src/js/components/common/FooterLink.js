import React, { Component } from 'react';

const FooterLink = ({ className, href, linkClick, content }) => {
    return (
        <p className={className}>
            <a href={href} onClick={linkClick} ><u>{content}</u></a>
        </p>
    );
};


FooterLink.defaultProps = {
    className: "No-thanks-I-dont-w",
    href: "#",
    content: "No thanks, I don’t want a loan at the moment"
};

export default FooterLink;
