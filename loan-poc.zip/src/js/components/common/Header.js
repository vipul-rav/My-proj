import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Route, Redirect, withRouter } from 'react-router-dom';
import { Link, NavLink } from 'react-router-dom';
import { DropdownButton, MenuItem } from 'react-bootstrap';
import _ from 'lodash';
import headerLogo from '../../../assets/images/logo.png';
import loginHeader from '../../../assets/images/login-header.jpg';


class Header extends React.Component {
  constructor(props, context) {
    super(props, context);
  }
  render() {
    return (
      <header className="page-header page-header-text">
        {this.props.loan.appHeader_text}
      </header>
    );
  }
}


function mapStateToProps(state, ownProps) {

  return {
    loan: state.loan
  };
}

function mapDispatchToProps(dispatch) {
  return {
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Header);
