import React, { Component } from 'react';
import Tick from '../../../assets/images/Tick.png';

const MessagesPanel = ({ classNames, content }) => {

    return (<div className={classNames.compenetClass}>
        <h1 className={classNames.HeadClass}>{content.header} </h1>
        <div className={classNames.BodyClass}>
            {content.bodyMessages.map((message, index) => {
                return (<div key={index}>
                    <img src={Tick} />
                    {message}
                </div>);
            })}
        </div>
    </div>
    );
};


MessagesPanel.defaultProps = {
    classNames: {
        compenetClass: "Rectangle-5",
        HeadClass: "Why-we-think-youre",
        BodyClass: "Lorem-ipsum-dolor-si"
    },
    content: {
        header: "Why we think you’re eligible",
        bodyMessages: [
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit",
            "Proin sollicitudin, quam sed malesuada rhoncus, risus massa scelerisque dolor, vitae consequat nunc",
            "In hac habitasse platea dictumst. Ut quis justo diam. Mauris dapibu"
        ]
    }
};

export default MessagesPanel;
