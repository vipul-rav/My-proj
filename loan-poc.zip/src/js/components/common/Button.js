import React, { Component } from 'react';
import Tick from '../../../assets/images/Tick.png';

const Button = ({ className, text, btnClick }) => {
    return (
        <button type="button" className={className} onClick={btnClick}>{text} </button>
    );
};


Button.defaultProps = {
    className: "Continue",
    text: "Continue"
};

export default Button;
