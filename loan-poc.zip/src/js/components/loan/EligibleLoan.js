/**
	* @module  EligibleLoan
	*/
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
//import mainImg from '../../../assets/images/Main Icon.png';
import TextHeader from '../common/TextHeader';
import MarketPromo from '../common/MarketPromo';
import MessagesPanel from '../common/MessagesPanel';
import Button from '../common/Button';
import FooterLink from '../common/FooterLink';
import * as StringConstant from '../../shared/constant/StringConstant';

class EligibleLoan extends React.Component {
  constructor(props, context) {
    super(props, context);
    this.continueClick = this.continueClick.bind(this);
  }

  continueClick() {
    this.props.continueClick(StringConstant.PREF_2);
  }

  buildPage() {
    if (this.props.content.controls != undefined) {
      return this.props.content.controls.map((control, index) => {
        switch (control.controlId.trim()) {
          case 'HeaderImage':
            let header = control.text.toString().replace("#amount", "<span class='personal-loan-info-text'>£" + this.props.data.elligibilityAmount + "</span>");
            header = header.replace("#year", "<span class='personal-loan-info-text'>" + this.props.data.elligibilityYear + "</span>");
            return <div key={index} className="topMargin-5">
              <TextHeader content={header} classNames={{ imgClass: "Frame", txtClass: "personal-loan-info" }} />
            </div>;
          case 'MarketHeader':
            return <div key={index} className="topMargin-5">
              <MarketPromo classNames={{ HeadClass: "page-heading", BodyClass: "page-paragraph" }} content={{ header: control.defaultValue, body: control.text }} />
            </div>;
          case 'ListHeaderText':
            return <MessagesPanel key={index}  content={{ header: control.defaultValue, bodyMessages: this.props.content.eligible_txt }}
              classNames={{
                compenetClass: "personalloan-rectangle",
                HeadClass: "eligibilityList-heading",
                BodyClass: "eligibilityList"
              }} />;
          case 'ContinueBtn':
            if (control.type === "Button")
              return <div key={index}><Button className="submit-button submit-button-text" btnClick={this.continueClick} text={control.text} /></div>
            else
              return <div key={index}><FooterLink className="link" content={control.text} linkClick={this.continueClick} /></div>;
          case 'FooterLink':
            return <div className="bottomMargin-3" key={index}><FooterLink content={control.text} className="prsnl-loan-bottomLine"/></div>;

        }
      });
    }
  }

  render() {


    return (
      <div className="row Marketing-promo">
        {this.buildPage()}
      </div>
    );
  }
}

EligibleLoan.propTypes = {
  continueClick: PropTypes.func.isRequired,
  content: PropTypes.object.isRequired,
  data: PropTypes.object.isRequired
};



export default EligibleLoan;