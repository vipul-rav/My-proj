/**
	* @module  LoanFor
	*/
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import car from '../../../assets/images/car.png';
import Holiday from '../../../assets/images/holiday.png';
import Home from '../../../assets/images/home.png';
import Something from '../../../assets/images/other.png';
import Debt from '../../../assets/images/debt.png';
import Button from '../common/Button';
import FooterLink from '../common/FooterLink';
import Image from '../common/Image';
import * as StringConstant from '../../shared/constant/StringConstant';



class LoanFor extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.continueClick = this.continueClick.bind(this);
  }

  continueClick() {
    this.props.continueClick(StringConstant.PREF_3);
  }

  getImages(loanImg) {
    const classNames = { imgClass: "Oval", textClass: "imgText" };

    switch (loanImg.controlId) {
      case "car":
        return <Image className={classNames} src={loanImg.defaultValue} imgText={loanImg.text} />;
      case "holiday":
        return <Image className={classNames} src={loanImg.defaultValue} imgText={loanImg.text} />;
      case "home":
        return <Image className={classNames} src={loanImg.defaultValue} imgText={loanImg.text} />;
      case "debt":
        return <Image className={classNames} src={loanImg.defaultValue} imgText={loanImg.text} />;
      case "other":
        return <Image className={classNames} src={loanImg.defaultValue} imgText={loanImg.text} />;
    }
  }

  buildPage() {
    return this.props.content.controls.map((control, index) => {
      if (control.type == 'Image') {
        return this.getImages(control);
      }
      else {
        switch (control.controlId.trim()) {
          case 'HeaderLabel':
            return <div className="What-do-you-plan-to" key={index}>
              {this.props.content.header_1_txt}
            </div>;
          case 'ContinueBtn':
            if (control.type === "Button")
              return <div key={index}><Button btnClick={this.continueClick} text={control.text} className="submit-button submit-button-text"/></div>
            else
             return <div key={index}><FooterLink className="link" content={control.text} linkClick={this.continueClick}/></div>;
          case 'FooterLink':
            return <div key={index}><FooterLink content={control.text} className="prsnl-loan-bottomLine"/></div>;

        }
      }
    });
  }


  render() {
    return (
       <div className="row Marketing-promo">
          {this.buildPage()}
      </div >
    );
  }
}

LoanFor.propTypes = {
  continueClick: PropTypes.func.isRequired,
  content: PropTypes.object.isRequired
};



export default LoanFor;























  {/*<div className="row">
          <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4">
            <img src={car} />
          </div>
          <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4">
            <img src={Holiday} />
          </div>
          <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4">
            <img src={Home} />
          </div>
        </div>
        <div className="row">
          <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 imgCenter">
            <img src={Debt} />
          </div>
          <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 imgCenter">
            <img src={Something} />
          </div>

        </div>*/}