/**
	* @module  Loan Appliction
	*/
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import Button from 'react-bootstrap/lib/Button';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import EligibleLoan from './EligibleLoan';
import LoanFor from './LoanFor';
import BorrowLoan from './BorrowLoan';
import * as LoanAction from '../../redux/actions/LoanAction';
import * as StringConstant from '../../shared/constant/StringConstant';


class LoanAppliction extends React.Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      stepText: StringConstant.PREF_1
    };

    this.props.actions.getLoanContent('CB', this.state.stepText);
    this.props.actions.getEligibleLoanData('CB', this.state.stepText);

    this.continueClick = this.continueClick.bind(this);

  }


  continueClick(step) {
    this.props.actions.getLoanContent('CB', step);
    
    if (step === StringConstant.PREF_3) {
      this.props.actions.getBorrowLoanData('CB', this.state.stepText);
      this.props.actions.getSliderAmount('CB', this.state.stepText);
    }

    this.setState({ stepText: step });
  }
  getLoanFor(content) {
    if (content != undefined && content.id != undefined)
      return <LoanFor continueClick={this.continueClick} content={content} />;
    else
      return <div>loading...</div>;
  }
  getEligibleLoan(content, data) {
    if (content != undefined && content.id != undefined && data != undefined)
      return <EligibleLoan continueClick={this.continueClick} content={content} data={data.eligibleAmount} />;
    else
      return <div>loading...</div>;
  }
  getBorrowLoan(loan) {
    if (loan != undefined && loan.borrowLoan != undefined && loan.borrowLoan.id != undefined)
      return <BorrowLoan continueClick={this.continueClick} content={loan.borrowLoan} data={loan} />;
    else
      return <div>loading...</div>;
  }

  setFlow(loan) {
    if (loan !== undefined) {
      switch (this.state.stepText) {
        case StringConstant.PREF_1:
          return this.getEligibleLoan(loan.eligibleLoan, loan.loanData);
        case StringConstant.PREF_2:
          return this.getLoanFor(loan.loanFor);
        case StringConstant.PREF_3:

          return this.getBorrowLoan(loan);
        default:
          return this.getEligibleLoan(loan.eligibleLoan, loan.loanData);
      }
    }
    else
      return <div>Loading..... </div>;
  }


  render() {

    return (
      <div className="container-fluid">
        {this.setFlow(this.props.Loan)}
      </div>
    );
  }
}

const mapStateToProps = state => ({ Loan: state.loan });


function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(LoanAction, dispatch)
  };
}

LoanAppliction.propTypes = {

};



export default connect(mapStateToProps, mapDispatchToProps)(LoanAppliction);