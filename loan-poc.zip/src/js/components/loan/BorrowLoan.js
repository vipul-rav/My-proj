/**
	* @module  EligibleLoan
	*/
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import Pound from '../../../assets/images/pnd.png';
import Minus from '../../../assets/images/Minus.png';
import Plus from '../../../assets/images/Plus.png';
import Slider from '../common/Slider';
import AmountPay from '../common/AmountPay';
import Button from '../common/Button';
import * as StringConstant from '../../shared/constant/StringConstant';

const Min = 500;
const Max = 2000;
const Step = 1000;
const MinTerm = 12;
const MaxTerm = 36;
const StepTerm = 5;

class BorrowLoan extends React.Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            txtAmt: this.props.data.loanData.sliderAmount.sliderMinAmount,
            monthlyPay: 0,
            totPay: 0,
            txttrm: MinTerm
        };

        this.continueClick = this.continueClick.bind(this);
        this.amtMinusClick = this.amtMinusClick.bind(this);
        this.amtPlusClick = this.amtPlusClick.bind(this);
        this.sliderChange = this.sliderChange.bind(this);
        this.getAmount = this.getAmount.bind(this);
        this.trmMinusClick = this.trmMinusClick.bind(this);
        this.trmPlusClick = this.trmPlusClick.bind(this);
        this.trmsliderChange = this.trmsliderChange.bind(this);
        this.getMonthlyRepay = this.getMonthlyRepay.bind(this);
        this.getTotalRepay = this.getTotalRepay.bind(this);
    }

    continueClick() {
        this.props.continueClick(StringConstant.PREF_1);
    }

    amtMinusClick() {
        this.setState({
            txtAmt: parseFloat(this.state.txtAmt) - parseFloat(Step)
        });
    }
    amtPlusClick() {
        this.setState({ txtAmt: parseFloat(this.state.txtAmt) + parseFloat(Step) });
    }
    sliderChange(e) {
        this.setState({ txtAmt: e.target.value });
    }
    getAmount() {

        return this.state.txtAmt;
    }
    trmMinusClick() {
        this.setState({ txttrm: parseFloat(this.state.txttrm) - parseFloat(StepTerm) });
    }
    trmPlusClick() {
        this.setState({ txttrm: parseFloat(this.state.txttrm) + parseFloat(StepTerm) });
    }
    trmsliderChange(e) {
        this.setState({ txttrm: e.target.value });
    }
    getTerm() {
        return this.state.txttrm;
    }
    getMonthlyRepay() {
        return parseFloat(this.state.txtAmt) * 5 / 100;
    }
    getTotalRepay() {
        return this.getMonthlyRepay() * parseFloat(this.state.txttrm);
    }

    buildPage() {
        return this.props.content.controls.map((control, index) => {
            switch (control.controlId.trim()) {
                case 'HeaderLabel':
                    let header = control.text.toString().replace("#amount1", this.props.data.loanData.borrowAmount.borrowMinAmount);
                    header = header.replace("#amount2", this.props.data.loanData.borrowAmount.borrowMaxAmount);
                    return <div className="You-can-borrow-betwe" key={index}>
                        {header}
                    </div>
                case 'SubHeaderLabel':
                    return <div className="If-youd-like-to-bor" key={index}>
                        {control.text}
                    </div>
                case 'AmountLabel':
                    return <table className="amount-range topMargin-10">
                        <tr className="Rectangle">
                            <td className="pound-sign">£</td>
                            <td className="show-amount">{this.getAmount()} </td>
                        </tr>
                    </table>;
                case 'SliderAmount':
                    const minAmt = this.props.data.loanData.sliderAmount.sliderMinAmount;
                    const maxAmt = this.props.data.loanData.sliderAmount.sliderMaxAmount;
                    return <div className="topMargin-10" key={index}>
                        <Slider attributes={{ value: this.getAmount(), step: Step, min: minAmt, max: maxAmt }}
                            sliderChange={this.sliderChange} minusClick={this.amtMinusClick} plusClick={this.amtPlusClick}
                            />
                    </div>;
                case 'SliderTerm':
                    return <div className="topMargin-20" key={index}>
                        <Slider attributes={{ value: this.getTerm(), step: StepTerm, min: MinTerm, max: MaxTerm }} sliderChange={this.trmsliderChange}
                            minusClick={this.trmMinusClick} plusClick={this.trmPlusClick}
                            />
                    </div>
                case 'MonthlyPanel':
                    return <div className="topMargin-20" key={index}><AmountPay classNames={{ mainClass: "mask mask-left", headerClass: "mask-upline", valueClass: "mask-downline" }}
                        headerText={control.text} value={this.getMonthlyRepay()} /></div>
                case 'TotalPanel':
                    return <div className="topMargin-20" key={index}><AmountPay classNames={{ mainClass: "mask mask-right", headerClass: "mask-upline", valueClass: "mask-downline" }} headerText={control.text} value={this.getTotalRepay()} /></div>
                case 'ContinueBtn':
                    return <span  key={index}>
                        {(control.type === "Button") ?
                            <Button className="submit-button submit-button-text continue-button" btnClick={this.continueClick} text={control.text} />
                            :
                            <FooterLink className="link" content={control.text} linkClick={this.continueClick} />
                        }
                    </span>

            }
        });
    }

    render() {
        return (
            <div className="row Marketing-promo">
                {this.buildPage()}
            </div>
        );
    }
}

BorrowLoan.propTypes = {
    continueClick: PropTypes.func.isRequired,
    data: PropTypes.object.isRequired

};



export default BorrowLoan;





















{ /*<div>
                    <img src={Minus} onClick={this.amtMinusClick} />
                    <input type="range" className="Slider" onChange={this.sliderChange} min={Min} max={Max} value={this.getAmount()} step={Step} />
                    <img src={Plus} onClick={this.amtPlusClick} />
                    <Slider attributes={amtAtributes} sliderChange={this.sliderChange} minusClick={this.amtMinusClick} plusClick={this.amtPlusClick} />
                </div>
                <div>
                    <img src={Minus} onClick={this.trmMinusClick} />
                    <input type="range" className="Slider" onChange={this.trmsliderChange} min={MinTerm} max={MaxTerm} value={this.getTerm()} step={StepTerm} />
                    <img src={Plus} onClick={this.trmPlusClick} />
                    <Slider attributes={termAtributes} sliderChange={this.sliderChange} minusClick={this.trmMinusClick} plusClick={this.trmPlusClick} />
                </div>
                <div>
                    <span className="Mask">
                        <div className="Monthly-repayments"> Monthly repayments </div>
                        <div className="pay-layer ">  {this.getMonthlyRepay()} </div>
                    </span>
                    <AmountPay classnmes={{ mainClass: "Mask", headerClass: "Monthly-repayments", valueClass: "pay-layer" }} headerText="Monthly repayments" value={this.getMonthlyRepay()} />
                    <AmountPay headerText="Total repayable" value={this.getTotalRepay()} />
                    <span className="Mask">
                        <div className="Monthly-repayments"> Total repayable </div>
                        <div className="pay-layer ">  {this.getTotalRepay()} </div>
                    </span>
                </div>

                <div className="Rectangle-4">
                    <Button btnClick={this.continueClick} />
                    <button type="button" className="Continue" onClick={this.continueClick}>Continue </button>
                </div>
            </div> */}


{/*const amtAtributes =
            {value: this.getAmount(), step: Step, min: Min, max: Max };
        const termAtributes =
            {value: this.getTerm(), step: StepTerm, min: MinTerm, max: MaxTerm };

        let header = this.props.content.header_1_txt.toString().replace("#amount1", "5K");
        header = header.replace("#amount2", "20K");

        return (
            <div className="row">
                    <div>
                        <div className="You-can-borrow-betwe">
                            {header}
                        </div>
                        <div className="If-youd-like-to-bor">
                            {this.props.content.header_2_txt}
                        </div>
                        <div className="amt-rectangle">
                            <span className="pndImg"><img src={Pound} /></span>
                            <span className="amt-layer ">{this.getAmount()}</span>
                        </div>
                        <div>
                            <Slider attributes={amtAtributes} sliderChange={this.sliderChange} minusClick={this.amtMinusClick} plusClick={this.amtPlusClick} />
                        </div>
                        <div>
                            <Slider attributes={termAtributes} sliderChange={this.trmsliderChange} minusClick={this.trmMinusClick} plusClick={this.trmPlusClick} />
                        </div>
                        <div>
                            <table className="tablePay">
                                <tbody>
                                    <tr>
                                        <td><AmountPay classnmes={{ mainClass: "Mask", headerClass: "Monthly-repayments", valueClass: "pay-layer" }} headerText={this.props.content.month_repay_tx} value={this.getMonthlyRepay()} /></td>
                                        <td><AmountPay headerText={this.props.content.total_repay_txt} value={this.getTotalRepay()} /></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div className="Rectangle-4">
                            <Button btnClick={this.continueClick} text={this.props.content.button_txt} />
                        </div>
                    </div>

                </div>
                );*/}