/**
	* @module  CustomerSearch
	*/

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import CustomerList from './CustomerList';
import CustomerSummary from './CustomerSummary';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as customerAction from '../../redux/actions/CustomerAction';
import FormGroup from 'react-bootstrap/lib/FormGroup';
import FormControl from 'react-bootstrap/lib/FormControl';
import Form from 'react-bootstrap/lib/Form';
import Row from 'react-bootstrap/lib/Row';
import Col from 'react-bootstrap/lib/Col';

class CustomerSearch extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: '',
      isSearch: false,
      last_name: '',
      postcode: '',
      initials: '',
      bankname: 'CB',
      _searchOnClick: false
    };
    this._searchOnClick = this._searchOnClick.bind(this);
    this.handleSurnameChange = this.handleSurnameChange.bind(this);
    this.handleInitialChange = this.handleInitialChange.bind(this);
    this.handlePostcodeChange = this.handlePostcodeChange.bind(this);
    this.handleNewSearch = this.handleNewSearch.bind(this);
    this.handleBanknameChange = this.handleBanknameChange.bind(this);
    this.onClick = this.onClick.bind(this);
  }

  /** To display Customer List */
  _searchOnClick() {
    this.setState({ isSearch: true });
    if (this.state.initials.length > 0 || this.state.postcode.length > 0) {
      this.props.actions.loadCustomer(this.state.bankname, this.state.last_name, this.state.initials, this.state.postcode);
    }
  }

  handleBanknameChange(e) {
    this.setState({ bankname: e.target.value });
  }

  /** To go to CustomerSummary to see Customer Details   */
  onClick(id) {
    this.props.actions.customerProduct(id);
    this.props.actions.customerDetails(id);
    this.props.actions.customerHistory(id);
    this.props.actions.customerService(id);
    this.props.history.push('/CustomerSummary');
  }

  handleSurnameChange(e) {
    this.setState({ last_name: e.target.value });
  }
  handleInitialChange(e) {
    this.setState({ initials: e.target.value });
  }
  handlePostcodeChange(e) {
    this.setState({ postcode: e.target.value });
  }
  handleNewSearch() {
    this.setState({ last_name: '', initials: '', postcode: '' });
  }
  render() {
    let isDisableSearch = false;
    if (this.state.last_name.length === 0) {
      isDisableSearch = true;
    }


    if (this.state.initials.length === 0 && this.state.postcode.length === 0)
      isDisableSearch = true;


    if (this.state.postcode.length !== 0 && this.state.postcode.length < 3) {
      isDisableSearch = true;
    }
    return (
      <div>
        <div className="container">
          <div className="row page-margin">
            <div className="col-md-offset-2 col-md-8 col-md-offset-2">
              <Form className="form-horizontal search">
                <div className="form-group">
                  <label className="control-label col-sm-2">Bank:</label>
                  <div className="col-sm-5">
                    <select className="form-control" defaultValue={this.state.bankname} onChange={this.handleBanknameChange}>
                      <option value="CB">Clydesdale Bank</option>
                      <option value="YB">Yorkshire Bank</option>
                    </select>
                  </div>
                  <button type="button" disabled={isDisableSearch} className="btn btn-size" onClick={this._searchOnClick}>Search</button>

                </div>

                <div className="form-group">
                  <label className="control-label col-sm-2">Surname:</label>
                  <div className="col-sm-5">
                    <input type="text" value={this.state.last_name} placeholder="surname" onChange={this.handleSurnameChange} className="form-control" id="usr" />
                  </div>
                  <button type="reset" className="btn btn-size" onClick={this.handleNewSearch}>Clear</button>
                </div>

                <div className="form-group">
                  <label className="control-label col-sm-2">1st Initial:</label>
                  <div className="col-sm-5">
                    <input type="text" placeholder="Initial" value={this.state.initials} onChange={this.handleInitialChange} maxLength="1" className="form-control" id="usr" />
                  </div>

                </div>

                <div className="form-group">
                  <label className="control-label col-sm-2">Post Code:</label>
                  <div className="col-sm-5">
                    <input type="text" placeholder="Post Code" value={this.state.postcode} onChange={this.handlePostcodeChange} maxLength="8" className="form-control" id="usr" />
                  </div>
                </div>
              </Form>
              <div>
                {this.props.loadCustomer.length > 0 && <CustomerList customers={this.props.loadCustomer} onClick={this.onClick} />}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

CustomerSearch.propTypes = {
  actions: PropTypes.object.isRequired,
  loadCustomer: PropTypes.array.isRequired,
  customerDetails: PropTypes.object.isRequired,
  customerProduct: PropTypes.object.isRequired,
  customerService: PropTypes.array.isRequired,
  customerHistory: PropTypes.array.isRequired,
  history: PropTypes.object.isRequired

};

function mapStateToProps(state, ownProps) {

  return {
    loadCustomer: state.customers.customers,
    customerDetails: state.customers.customerDetail,
    customerProduct: state.customers.customerProduct,
    customerHistory: state.customers.customerHistory,
    customerService: state.customers.customerService

  };
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(customerAction, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(CustomerSearch);
