/**
	* @module  CustomerInformation
	*/

import React, { PropTypes } from 'react';
import Form from 'react-bootstrap/lib/Form';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as customerAction from '../../redux/actions/CustomerAction';

class CustomerInformation extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
           
        };
    }

    render() {
        return (
            <div>
                <Form className="form-horizontal">
                    <div className="form-group">
                        <label className="control-label col-sm-2">Name:</label>
                        <div className="col-sm-4">
                            <label className="form-control">{this.props.customerDetail.display_name}</label>
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="control-label col-sm-2">Type:</label>
                        <div className="col-sm-4">
                           <label className="form-control"></label>
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="control-label col-sm-2">Date Of Birth:</label>
                        <div className="col-sm-4">
                            <label className="form-control">{this.props.customerDetail.personal_details.dob}</label>
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-2">Contact Details:</label>
                        <div className="col-sm-4">
                            <select className="form-control">
                                <option>Work {this.props.customerDetail.contact_details.phone.work}</option>
                                <option>Mobile {this.props.customerDetail.contact_details.phone.mobile}</option>
                                <option>Home {this.props.customerDetail.contact_details.phone.home}</option>
                            </select>
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="control-label col-sm-2">Address:</label>
                        <div className="col-sm-4">
                            <label className="form-control area-size" style={{ "height": "164px", "width": "360px" }}>
                                {this.props.customerDetail.personal_details.addresses[0].uk_address.address_prefix}<br/>
                                {this.props.customerDetail.personal_details.addresses[0].uk_address.house_number}<br/>
                                {this.props.customerDetail.personal_details.addresses[0].uk_address.house_name}<br/>
                                {this.props.customerDetail.personal_details.addresses[0].uk_address.street_name}<br/>
                                {this.props.customerDetail.personal_details.addresses[0].uk_address.address_line_1}
                                {this.props.customerDetail.personal_details.addresses[0].uk_address.address_line_2}
                                {this.props.customerDetail.personal_details.addresses[0].uk_address.city}<br/>  
                                {this.props.customerDetail.personal_details.addresses[0].uk_address.postal_code}
                                {this.props.customerDetail.personal_details.addresses[0].uk_address.county}
                            </label>
                        </div>
                    </div>
                </Form>
            </div>
        );
    }
}
CustomerInformation.propTypes = {
    customerDetail: PropTypes.object.isRequired

};

function mapStateToProps(state, ownProps) {
    return {
        customerDetails: state.customers
    };
}
function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(customerAction, dispatch)
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(CustomerInformation);