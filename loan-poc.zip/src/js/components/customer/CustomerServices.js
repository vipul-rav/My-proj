/**
	* @module  CustomerServices
	*/

import React, { PropTypes } from 'react';
import Form from 'react-bootstrap/lib/Form';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as customerAction from '../../redux/actions/CustomerAction';

class CustomerServices extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
             <div className="table-style">
                <table className="table">
                <thead>
                    <tr>
                        <th>Service</th>
                        <th>Active</th>
                        <th>Inactive Reason</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    {this.props.customerService.map( (service,index )=> {
                        return (
                            <tr key={index}>
                            <td>{service.service_name}</td>
                            <td>{service.active}</td>
                            <td>{service.inactive_reason}</td>
                            <td>{service.date}</td>
                        </tr>
                        );
                    })
                    }
                </tbody>
            </table>
            </div>
        );

    }
}

CustomerServices.propTypes = {
    customerService: PropTypes.array.isRequired
};



export default CustomerServices;