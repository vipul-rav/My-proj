/**
	* @module  CustomerList
	*/

import React, {PropTypes} from 'react';
import CustomerListRow from './CustomerListRow';
import CustomerSearch from './CustomerSearch';

const CustomerList = ({customers,onClick}) => {
  return (
    
    <table className="table summary-style">
      <thead>
      <tr>
        <th>&nbsp;</th>
        <th>Customer Id</th>
        <th>Name</th>
        <th>Address</th>
        <th>Post Code</th>
      </tr>
      </thead>
      <tbody>
          {customers.map(customer =>
        <CustomerListRow key={customer.id} customer={customer} onClick={onClick}/>
      )}
      
      </tbody>
    </table>
    
  );
};

CustomerList.propTypes = {
  customers: PropTypes.array.isRequired,
  onClick: PropTypes.func.isRequired
  
};

export default CustomerList;
