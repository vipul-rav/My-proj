import React from 'react';
import { shallow, mount } from 'enzyme';
import LoginForm from '../LoginForm';
import expect from 'expect';

const props = {
    handleSubmit: jest.fn(),
    errorMsg: ""
};


describe('Login Form components', () => {

    it('should call userId change', () => {

        const Wrapper = mount(<LoginForm {...props} />);

        const input = Wrapper.find('input[type="Id"]');

        input.props().onChange({
            target: {
                value: 'user'
            }
        })

        expect(Wrapper.state().Id).toEqual("user");
    });

    it('should call password change', () => {

        const Wrapper = mount(<LoginForm {...props} />);

        const input = Wrapper.find('input[type="password"]');

        input.props().onChange({
            target: {
                value: 'password'
            }
        })

        expect(Wrapper.state().password).toEqual("password");
    });

    it('should call redirectToDashboard', () => {

        const Wrapper = mount(<LoginForm {...props} />);

        const input = Wrapper.find('button');

        input.props().onClick();
       

       expect(Wrapper.props().handleSubmit.mock.calls.length).toBe(1);
    });


});