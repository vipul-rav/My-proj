
import 'babel-polyfill';
import promise from 'es6-promise';
import React from 'react';
import { render } from 'react-dom';
import configureStore from './js/shared/store/ConfigureStore';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import Routes from './Routes';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import App from './js/components/App';
//import './assets/styles/common.css';
import './assets/styles/main.scss';

const store = configureStore();
const reactElement = document.getElementById('react');


export const Root = () => (
  <Provider store={store}>
    <BrowserRouter><Routes/></BrowserRouter>
  </Provider>
);


if (!module.hot) {
  render(<Root />, reactElement);
}
