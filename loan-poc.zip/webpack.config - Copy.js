
const path = require('path');
const webpack = require('webpack');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const CopyWebpackPlugin = require('copy-webpack-plugin');
const nodeEnv = process.env.NODE_ENV || 'development';
const DashboardPlugin = require('webpack-dashboard/plugin');
const isProduction = nodeEnv === 'production';

const autoprefixer = require('autoprefixer');
const SpritePlugin = require('svg-sprite-loader/plugin');

process.noDeprecation = true;
const SRC_PATH = path.join(__dirname, './src');
const buildPath = path.join(__dirname, './build');
const sourcePath = path.join(__dirname, './src');

const cleanDist = new CleanWebpackPlugin(['dist', 'build'], {
    root: path.resolve(__dirname, './'),
    verbose: true,
    dry: false
});

// Common plugins
const plugins = [
    new SpritePlugin(),
    new webpack.optimize.CommonsChunkPlugin({
        name: 'vendor',
        filename: 'vendor-[hash].js',
        minChunks(module) {
            const context = module.context;
            return context && context.indexOf('node_modules') >= 0;
        }
    }),
    new webpack.DefinePlugin({
        'process.env': {
            NODE_ENV: JSON.stringify(nodeEnv)
        }
    }),
    cleanDist,
    new webpack.NamedModulesPlugin(),
    new HtmlWebpackPlugin({
        title: 'Telephony Banking',
        template: path.join('../tools/', 'index.html'),
        path: path.join(__dirname, './build'),
        filename: 'index.html'
    }),
    new webpack.LoaderOptionsPlugin({
        options: {
            postcss: [
                autoprefixer({
                    browsers: [
                        'last 3 version',
                        'ie >= 10'
                    ]
                })
            ],
            context: SRC_PATH
        }
    })
];


// Common rules
const rules = [
    {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: [
            'babel-loader',
        ],
    },

    {
        test: /\.(png|gif|jpg|svg)$/,
        include: path.join(__dirname, './src/assets/images'),
        use: 'url-loader?limit=20480&name=assets/[name]-[hash].[ext]'
    }
];


if (isProduction) {
    // Production plugins
    plugins.push(
        new webpack.optimize.UglifyJsPlugin({
            compress: {
                warnings: false,
                screw_ie8: true,
                conditionals: true,
                unused: true,
                comparisons: true,
                sequences: true,
                dead_code: true,
                evaluate: true,
                if_return: true,
                join_vars: true
            },
            output: {
                comments: false
            }
        }),
        new ExtractTextPlugin('style-[hash].css')
    );

    // Production rules
    rules.push(
        {
            test: /\.css$/,
            loader: ExtractTextPlugin.extract({
                fallback: 'style-loader',
                use: 'css-loader', //!postcss-loader!sass-loader
            }),
        }
    );
} else {
    // Development plugins
    plugins.push(
        new webpack.HotModuleReplacementPlugin(),
        new DashboardPlugin()
    );

    // Development rules
    rules.push(
        {
            test: /\.css$/,
            // exclude: /node_modules/,
            use: [
                'style-loader',
                // Using source maps breaks urls in the CSS loader
                // https://github.com/webpack/css-loader/issues/232
                // This comment solves it, but breaks testing from a local network
                // https://github.com/webpack/css-loader/issues/232#issuecomment-240449998
                // 'css-loader?sourceMap',
                'css-loader',
                // 'postcss-loader',
                //'sass-loader?sourceMap'

            ]
        },
        {
            test: /\.(png|gif|jpg|svg)$/,
            include: path.join(__dirname, './source/assets/images'),
            use: 'url-loader?limit=20480&name=assets/[name]-[hash].[ext]'
        },
        {
            test: /\.woff$/,
            loader: 'url-loader',
            options: {
                name: '[path][name].[ext]',
                limit: 10000,
                mimetype: 'application/font-woff'
            }
        }, {
            test: /\.woff2$/,
            loader: 'url-loader',
            options: {
                name: '[path][name].[ext]',
                limit: 10000,
                mimetype: 'application/font-woff2'
            }
        }, {
            test: /\.(svg|eot|ttf|otf)$/, //load fonts
            loader: 'url-loader',
            options: {
                name: '[path][name].[ext]',
                limit: 10000
            }
        }
    );
}


module.exports = {
    devtool: 'source-map',
    context: SRC_PATH,
    entry: {
        js: './index.js',
        app: path.resolve(__dirname, './tools/hotReload')
    },
    output: {
        path: path.join(__dirname, './build'),
        publicPath: '/',
        filename: '[name]-[hash].js'
    },
    module: {
        rules
    },
    resolve: {
        extensions: ['.webpack-loader.js', '.web-loader.js', '.loader.js', '.js', '.jsx'],
        modules: [
            path.resolve(__dirname, 'node_modules'),
            SRC_PATH
        ]
    },
    plugins,
    devServer: {
        contentBase: isProduction ? buildPath : sourcePath,
        historyApiFallback: true,
        port: 3010,
        compress: isProduction,
        inline: !isProduction,
        hot: true,
        host: 'localhost',
        disableHostCheck: true,
        stats: {
            assets: true,
            children: false,
            chunks: false,
            hash: false,
            modules: false,
            publicPath: false,
            timings: true,
            version: false,
            warnings: true,
            colors: {
                green: '\u001b[32m'
            }
        }
    }
};

/*
module.exports = {
  context: path.resolve(__dirname, '../src'),
  entry: {
    app: [
      '../src'
    ],
    vendor: [
      'react',
      'react-dom',
      'react-router-dom'
    ]
  },
  output: {
    path: path.resolve(__dirname, '../build'),
    filename: '[name].bundle.[hash].js',
    publicPath: '/'
  },
  resolve: {
    modules: [SRC_PATH, 'node_modules'],
    extensions: ['.js', '.jsx', '.json', 'jsonp']
  },
  node: {
    fs: 'empty',
    net: 'empty',
    tls: 'empty'
  },
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'babel-loader',
            options: {
              babelrc: false,
              presets: [
                ["env", { "modules": false }],
                "react",
                "stage-0"
                // Transpile React components to JavaScript
              ],
              plugins: ['react-hot-loader/babel', 'react-html-attrs', 'transform-class-properties', 'transform-decorators-legacy']
            }
          }
        ]
      },
      {
        test: /\.(css)$/, //load css || load scss  // /\.(scss|css)$/
        use: ['style-loader', 'css-loader'] //,'sass-loader'   //['style-loader','css-loader']
      },
      {
        test: /\.(png|jpe?g|gif|ico)$/, //load images
        use: [
          {
            loader: 'img-loader',
            options: {
              name: '[path][name].[ext]',
              limit: 10000
            }
          },
          'url-loader?limit=10000'
        ]
      }, {
        test: /\.woff$/,
        loader: 'url-loader',
        options: {
          name: '[path][name].[ext]',
          limit: 10000,
          mimetype: 'application/font-woff'
        }
      }, {
        test: /\.woff2$/,
        loader: 'url-loader',
        options: {
          name: '[path][name].[ext]',
          limit: 10000,
          mimetype: 'application/font-woff2'
        }
      }, {
        test: /\.(svg|eot|ttf|otf)$/, //load fonts
        loader: 'url-loader',
        options: {
          name: '[path][name].[ext]',
          limit: 10000
        }
      }, {
        test: /\.(webm|mp4)$/, //load videos file
        loader: 'file-loader',
        options: {
          name: '[path][name].[ext]',
          limit: 10000
        }
      }, {
        test: /\.json$/,
        loader: 'json-loader',
        options: {
          name: '[path][name].[ext]'
        }
      }
    ]
  },
  plugins: [
    cleanDist,
    HtmlPlugin,
    new SpritePlugin(),
    new ExtractTextPlugin({
      filename: "[name].[hash].css",
      allChunks: false
    }),
    
    new webpack.optimize.CommonsChunkPlugin({
      names: ['vendor', 'manifest'],
      minChunks(module) {
        const context = module.context;
        return context && context.indexOf('node_modules') >= 0;
      }
    }),
    new CopyWebpackPlugin([
      {
        from: '../src/stubs/*.json',
        to: '[path][name].[ext]'
      }
    ]),
    new webpack.LoaderOptionsPlugin({
      options: {
        postcss: [
          autoprefixer({
            browsers: [
              'last 3 version',
              'ie >= 10'
            ]
          })
        ],
        context: SRC_PATH
      }
    })
  ]
};
*/

// module.exports = env => {
//     return env === 'dev'
//         ? require('./tools/webpack.config.dev')
//         : require('./tools/webpack.config.prod');
// };