module.exports = env => {
    return env === 'dev'
        ? require('./tools/webpack.config.dev')
        : require('./tools/webpack.config.prod');
};